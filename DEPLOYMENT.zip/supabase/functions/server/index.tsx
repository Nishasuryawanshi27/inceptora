import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "jsr:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Create Supabase client for auth
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-e8579b4d/health", (c) => {
  return c.json({ status: "ok" });
});

// ============================================
// AUTH ROUTES
// ============================================

// Sign up with email/password
app.post("/make-server-e8579b4d/auth/signup", async (c) => {
  try {
    const { email, password, name, role, interests, skills } = await c.req.json();
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, role, interests, skills },
      // Automatically confirm the user's email since an email server hasn't been configured
      email_confirm: true
    });

    if (error) {
      console.error('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }

    // Create user profile in kv store
    await kv.set(`profile:${data.user.id}`, {
      id: data.user.id,
      name,
      email,
      role,
      interests: interests || [],
      skills: skills || [],
      bio: '',
      location: '',
      profilePicture: null,
      createdAt: new Date().toISOString()
    });

    return c.json({ success: true, user: data.user });
  } catch (error) {
    console.error('Signup error:', error);
    return c.json({ error: 'Signup failed' }, 500);
  }
});

// Sign in with Google OAuth
app.post("/make-server-e8579b4d/auth/google", async (c) => {
  try {
    // Note: Frontend will handle OAuth redirect
    // This endpoint is for reference - actual OAuth happens client-side
    return c.json({ 
      message: 'Google OAuth should be handled on the frontend using supabase.auth.signInWithOAuth({ provider: "google" })',
      setupRequired: 'Please configure Google OAuth at https://supabase.com/docs/guides/auth/social-login/auth-google'
    });
  } catch (error) {
    console.error('Google auth error:', error);
    return c.json({ error: 'Google auth failed' }, 500);
  }
});

// ============================================
// PROFILE ROUTES
// ============================================

// Get user profile
app.get("/make-server-e8579b4d/profile/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const profile = await kv.get(`profile:${userId}`);
    
    if (!profile) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    return c.json({ profile });
  } catch (error) {
    console.error('Get profile error:', error);
    return c.json({ error: 'Failed to get profile' }, 500);
  }
});

// Update user profile
app.put("/make-server-e8579b4d/profile/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    // Verify user is authenticated
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (!user || user.id !== userId) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const updates = await c.req.json();
    const currentProfile = await kv.get(`profile:${userId}`);
    
    const updatedProfile = {
      ...currentProfile,
      ...updates,
      id: userId,
      updatedAt: new Date().toISOString()
    };

    await kv.set(`profile:${userId}`, updatedProfile);
    return c.json({ success: true, profile: updatedProfile });
  } catch (error) {
    console.error('Update profile error:', error);
    return c.json({ error: 'Failed to update profile' }, 500);
  }
});

// Get all profiles for discovery
app.get("/make-server-e8579b4d/profiles/discover", async (c) => {
  try {
    const profiles = await kv.getByPrefix('profile:');
    return c.json({ profiles: profiles.map(p => p.value) });
  } catch (error) {
    console.error('Get profiles error:', error);
    return c.json({ error: 'Failed to get profiles' }, 500);
  }
});

// ============================================
// POSTS & FEED ROUTES
// ============================================

// Create a post
app.post("/make-server-e8579b4d/posts", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { content, type, tags } = await c.req.json();
    const profile = await kv.get(`profile:${user.id}`);
    
    const postId = `post:${Date.now()}:${user.id}`;
    const post = {
      id: postId,
      userId: user.id,
      author: profile?.name || 'Anonymous',
      avatar: profile?.avatar || '👤',
      content,
      type,
      tags: tags || [],
      likes: 0,
      comments: 0,
      saved: false,
      liked: false,
      commentList: [],
      createdAt: new Date().toISOString()
    };

    await kv.set(postId, post);
    return c.json({ success: true, post });
  } catch (error) {
    console.error('Create post error:', error);
    return c.json({ error: 'Failed to create post' }, 500);
  }
});

// Get all posts for feed
app.get("/make-server-e8579b4d/posts", async (c) => {
  try {
    const posts = await kv.getByPrefix('post:');
    const sortedPosts = posts
      .map(p => p.value)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    return c.json({ posts: sortedPosts });
  } catch (error) {
    console.error('Get posts error:', error);
    return c.json({ error: 'Failed to get posts' }, 500);
  }
});

// Like/unlike a post
app.post("/make-server-e8579b4d/posts/:postId/like", async (c) => {
  try {
    const postId = c.req.param('postId');
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const post = await kv.get(postId);
    if (!post) {
      return c.json({ error: 'Post not found' }, 404);
    }

    const likeKey = `like:${postId}:${user.id}`;
    const existingLike = await kv.get(likeKey);

    if (existingLike) {
      // Unlike
      await kv.del(likeKey);
      post.likes = Math.max(0, post.likes - 1);
    } else {
      // Like
      await kv.set(likeKey, { userId: user.id, postId, createdAt: new Date().toISOString() });
      post.likes += 1;
    }

    await kv.set(postId, post);
    return c.json({ success: true, post, liked: !existingLike });
  } catch (error) {
    console.error('Like post error:', error);
    return c.json({ error: 'Failed to like post' }, 500);
  }
});

// Add comment to post
app.post("/make-server-e8579b4d/posts/:postId/comments", async (c) => {
  try {
    const postId = c.req.param('postId');
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { content } = await c.req.json();
    const profile = await kv.get(`profile:${user.id}`);
    const post = await kv.get(postId);
    
    if (!post) {
      return c.json({ error: 'Post not found' }, 404);
    }

    const comment = {
      id: Date.now(),
      author: profile?.name || 'Anonymous',
      avatar: profile?.avatar || '👤',
      content,
      time: 'just now',
      createdAt: new Date().toISOString()
    };

    post.commentList = post.commentList || [];
    post.commentList.push(comment);
    post.comments = post.commentList.length;

    await kv.set(postId, post);
    return c.json({ success: true, comment, post });
  } catch (error) {
    console.error('Add comment error:', error);
    return c.json({ error: 'Failed to add comment' }, 500);
  }
});

// ============================================
// MATCHES ROUTES
// ============================================

// Create a match (swipe right)
app.post("/make-server-e8579b4d/matches", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { targetUserId, action } = await c.req.json(); // action: 'like' or 'pass'
    
    const swipeKey = `swipe:${user.id}:${targetUserId}`;
    await kv.set(swipeKey, { 
      userId: user.id, 
      targetUserId, 
      action,
      createdAt: new Date().toISOString() 
    });

    // Check for mutual match
    if (action === 'like') {
      const reverseSwipe = await kv.get(`swipe:${targetUserId}:${user.id}`);
      if (reverseSwipe && reverseSwipe.action === 'like') {
        // It's a match!
        const matchKey = `match:${[user.id, targetUserId].sort().join(':')}`;
        await kv.set(matchKey, {
          users: [user.id, targetUserId],
          createdAt: new Date().toISOString()
        });
        return c.json({ success: true, matched: true });
      }
    }

    return c.json({ success: true, matched: false });
  } catch (error) {
    console.error('Create match error:', error);
    return c.json({ error: 'Failed to create match' }, 500);
  }
});

// Get user's matches
app.get("/make-server-e8579b4d/matches/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const allMatches = await kv.getByPrefix('match:');
    
    const userMatches = allMatches
      .filter(m => m.value.users.includes(userId))
      .map(m => m.value);

    return c.json({ matches: userMatches });
  } catch (error) {
    console.error('Get matches error:', error);
    return c.json({ error: 'Failed to get matches' }, 500);
  }
});

// ============================================
// MESSAGES/CHAT ROUTES
// ============================================

// Send a message
app.post("/make-server-e8579b4d/messages", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { recipientId, content } = await c.req.json();
    const conversationId = [user.id, recipientId].sort().join(':');
    const messageKey = `message:${conversationId}:${Date.now()}`;

    const message = {
      id: messageKey,
      conversationId,
      senderId: user.id,
      recipientId,
      content,
      read: false,
      createdAt: new Date().toISOString()
    };

    await kv.set(messageKey, message);
    
    // Update conversation metadata
    await kv.set(`conversation:${conversationId}`, {
      id: conversationId,
      participants: [user.id, recipientId],
      lastMessage: content,
      lastMessageAt: new Date().toISOString()
    });

    return c.json({ success: true, message });
  } catch (error) {
    console.error('Send message error:', error);
    return c.json({ error: 'Failed to send message' }, 500);
  }
});

// Get messages for a conversation
app.get("/make-server-e8579b4d/messages/:conversationId", async (c) => {
  try {
    const conversationId = c.req.param('conversationId');
    const messages = await kv.getByPrefix(`message:${conversationId}:`);
    
    const sortedMessages = messages
      .map(m => m.value)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

    return c.json({ messages: sortedMessages });
  } catch (error) {
    console.error('Get messages error:', error);
    return c.json({ error: 'Failed to get messages' }, 500);
  }
});

// Get all conversations for a user
app.get("/make-server-e8579b4d/conversations/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const allConversations = await kv.getByPrefix('conversation:');
    
    const userConversations = allConversations
      .filter(conv => conv.value.participants.includes(userId))
      .map(conv => conv.value)
      .sort((a, b) => new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime());

    return c.json({ conversations: userConversations });
  } catch (error) {
    console.error('Get conversations error:', error);
    return c.json({ error: 'Failed to get conversations' }, 500);
  }
});

Deno.serve(app.fetch);