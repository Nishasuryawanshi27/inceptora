import { projectId, publicAnonKey } from '../../utils/supabase/info';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-e8579b4d`;

// Store access token in memory (in production, consider more secure storage)
let accessToken: string | null = null;

export const setAccessToken = (token: string | null) => {
  accessToken = token;
};

export const getAccessToken = () => accessToken;

const getHeaders = (authenticated: boolean = false) => {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  
  if (authenticated && accessToken) {
    headers['Authorization'] = `Bearer ${accessToken}`;
  } else {
    headers['Authorization'] = `Bearer ${publicAnonKey}`;
  }
  
  return headers;
};

// Auth API
export const authAPI = {
  signup: async (email: string, password: string, name: string, role: string, interests: string[], skills: string[]) => {
    const response = await fetch(`${API_BASE}/auth/signup`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ email, password, name, role, interests, skills }),
    });
    return response.json();
  },
};

// Profile API
export const profileAPI = {
  get: async (userId: string) => {
    const response = await fetch(`${API_BASE}/profile/${userId}`, {
      headers: getHeaders(),
    });
    return response.json();
  },
  
  update: async (userId: string, updates: any) => {
    const response = await fetch(`${API_BASE}/profile/${userId}`, {
      method: 'PUT',
      headers: getHeaders(true),
      body: JSON.stringify(updates),
    });
    return response.json();
  },
  
  discover: async () => {
    const response = await fetch(`${API_BASE}/profiles/discover`, {
      headers: getHeaders(),
    });
    return response.json();
  },
};

// Posts API
export const postsAPI = {
  getAll: async () => {
    const response = await fetch(`${API_BASE}/posts`, {
      headers: getHeaders(),
    });
    return response.json();
  },
  
  create: async (content: string, type: string, tags: string[]) => {
    const response = await fetch(`${API_BASE}/posts`, {
      method: 'POST',
      headers: getHeaders(true),
      body: JSON.stringify({ content, type, tags }),
    });
    return response.json();
  },
  
  like: async (postId: string) => {
    const response = await fetch(`${API_BASE}/posts/${postId}/like`, {
      method: 'POST',
      headers: getHeaders(true),
    });
    return response.json();
  },
  
  addComment: async (postId: string, content: string) => {
    const response = await fetch(`${API_BASE}/posts/${postId}/comments`, {
      method: 'POST',
      headers: getHeaders(true),
      body: JSON.stringify({ content }),
    });
    return response.json();
  },
};

// Matches API
export const matchesAPI = {
  create: async (targetUserId: string, action: 'like' | 'pass') => {
    const response = await fetch(`${API_BASE}/matches`, {
      method: 'POST',
      headers: getHeaders(true),
      body: JSON.stringify({ targetUserId, action }),
    });
    return response.json();
  },
  
  getAll: async (userId: string) => {
    const response = await fetch(`${API_BASE}/matches/${userId}`, {
      headers: getHeaders(true),
    });
    return response.json();
  },
};

// Messages API
export const messagesAPI = {
  send: async (recipientId: string, content: string) => {
    const response = await fetch(`${API_BASE}/messages`, {
      method: 'POST',
      headers: getHeaders(true),
      body: JSON.stringify({ recipientId, content }),
    });
    return response.json();
  },
  
  getConversation: async (conversationId: string) => {
    const response = await fetch(`${API_BASE}/messages/${conversationId}`, {
      headers: getHeaders(true),
    });
    return response.json();
  },
  
  getConversations: async (userId: string) => {
    const response = await fetch(`${API_BASE}/conversations/${userId}`, {
      headers: getHeaders(true),
    });
    return response.json();
  },
};
