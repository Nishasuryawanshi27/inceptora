import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Search, MoreVertical, Send, Bell, Calendar } from 'lucide-react';
import { Screen } from '../App';

interface ChatScreenProps {
  navigateTo: (screen: Screen) => void;
}

const conversations = [
  { id: 1, name: 'Sarah Chen', lastMessage: 'That sounds great! When can we chat?', time: '2m', unread: 2, avatar: '🎨' },
  { id: 2, name: 'Alex Kumar', lastMessage: 'I have experience with React and Node', time: '1h', unread: 0, avatar: '💻' },
  { id: 3, name: 'Maya Patel', lastMessage: 'Thanks for connecting!', time: '3h', unread: 1, avatar: '📈' },
  { id: 4, name: 'Marcus Johnson', lastMessage: 'Let me know if you need any help', time: '1d', unread: 0, avatar: '🚀' },
];

const messages = [
  { id: 1, text: 'Hey! Saw your profile and loved your work', sender: 'them', time: '10:30 AM' },
  { id: 2, text: 'Thanks! Your design portfolio is amazing too', sender: 'me', time: '10:32 AM' },
  { id: 3, text: "I'm looking for a technical cofounder for my startup", sender: 'them', time: '10:33 AM' },
  { id: 4, text: 'That sounds interesting! Tell me more', sender: 'me', time: '10:35 AM' },
  { id: 5, text: "It's an AI-powered design tool for teams", sender: 'them', time: '10:36 AM' },
  { id: 6, text: 'That sounds great! When can we chat?', sender: 'them', time: '10:37 AM' },
];

export default function ChatScreen({ navigateTo }: ChatScreenProps) {
  const [selectedChat, setSelectedChat] = useState<number | null>(null);
  const [messageText, setMessageText] = useState('');

  const handleSendMessage = () => {
    if (messageText.trim()) {
      setMessageText('');
    }
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#0a0e27] to-[#050811]">
      <AnimatePresence mode="wait">
        {!selectedChat ? (
          // Conversations List
          <motion.div
            key="list"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="h-full flex flex-col"
          >
            {/* Header */}
            <div className="px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12 pb-4">
              <div className="flex items-center justify-between mb-4 sm:mb-6">
                <button
                  onClick={() => navigateTo('feed')}
                  className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors touch-manipulation"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <h2 className="text-lg sm:text-xl font-bold">Messages</h2>
                <div className="flex items-center gap-2">
                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    whileHover={{ scale: 1.05 }}
                    onClick={() => navigateTo('events')}
                    className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors relative touch-manipulation"
                  >
                    <Calendar className="w-5 h-5 text-[#a855f7]" strokeWidth={2} />
                  </motion.button>
                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    whileHover={{ scale: 1.05 }}
                    onClick={() => navigateTo('notifications')}
                    className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors relative touch-manipulation"
                  >
                    <Bell className="w-5 h-5 text-[#2dd4bf]" strokeWidth={2} />
                    <span className="absolute top-1 right-1 w-2 h-2 bg-[#fb923c] rounded-full border border-[#0a0e27]" />
                  </motion.button>
                </div>
              </div>

              {/* Search */}
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search messages..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl pl-12 pr-4 py-3 focus:outline-none focus:border-[#2dd4bf]/50 transition-colors"
                />
              </div>
            </div>

            {/* Conversations */}
            <div className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 pb-24 sm:pb-28 lg:pb-32">
              <div className="max-w-4xl mx-auto space-y-2">
                {conversations.map((conv) => (
                  <motion.button
                    key={conv.id}
                    onClick={() => setSelectedChat(conv.id)}
                    whileTap={{ scale: 0.98 }}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 hover:bg-white/10 hover:border-white/20 transition-colors text-left"
                  >
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#2dd4bf] to-[#a855f7] flex items-center justify-center text-2xl">
                          {conv.avatar}
                        </div>
                        {conv.unread > 0 && (
                          <div className="absolute -top-1 -right-1 w-6 h-6 bg-[#fb923c] rounded-full flex items-center justify-center text-xs font-bold">
                            {conv.unread}
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-semibold truncate">{conv.name}</h4>
                          <span className="text-xs text-gray-400">{conv.time}</span>
                        </div>
                        <p className={`text-sm truncate ${conv.unread > 0 ? 'text-white font-medium' : 'text-gray-400'}`}>
                          {conv.lastMessage}
                        </p>
                      </div>
                    </div>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        ) : (
          // Chat View
          <motion.div
            key="chat"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="h-full flex flex-col"
          >
            {/* Chat Header */}
            <div className="px-6 pt-12 pb-4 bg-white/5 border-b border-white/10 backdrop-blur-xl">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setSelectedChat(null)}
                  className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <div className="flex-1 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#2dd4bf] to-[#a855f7] flex items-center justify-center text-lg">
                    {conversations.find(c => c.id === selectedChat)?.avatar}
                  </div>
                  <div>
                    <h3 className="font-semibold">{conversations.find(c => c.id === selectedChat)?.name}</h3>
                    <p className="text-xs text-gray-400">Active now</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto px-6 py-6">
              <div className="space-y-4">
                {messages.map((msg) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[75%] ${msg.sender === 'me' ? 'order-2' : 'order-1'}`}>
                      <div
                        className={`px-4 py-3 rounded-2xl ${
                          msg.sender === 'me'
                            ? 'bg-gradient-to-r from-[#2dd4bf] to-[#a855f7] text-white rounded-br-md'
                            : 'bg-white/5 border border-white/10 text-white rounded-bl-md'
                        }`}
                      >
                        <p className="text-sm">{msg.text}</p>
                      </div>
                      <p className={`text-xs text-gray-400 mt-1 ${msg.sender === 'me' ? 'text-right' : 'text-left'}`}>
                        {msg.time}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Input */}
            <div className="px-4 sm:px-6 pb-24 sm:pb-28 pt-4 border-t border-white/10 bg-gradient-to-t from-[#0a0e27] via-[#0a0e27] to-transparent">
              <div className="flex gap-3">
                <input
                  type="text"
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Type a message..."
                  className="flex-1 h-12 px-4 bg-white/5 border border-white/10 rounded-2xl text-white placeholder-gray-500 focus:outline-none focus:border-[#2dd4bf] transition-colors"
                />
                <button
                  onClick={handleSendMessage}
                  className="w-12 h-12 bg-gradient-to-r from-[#fb923c] to-[#f97316] rounded-2xl flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow touch-manipulation"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}