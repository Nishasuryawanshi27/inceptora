import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  ArrowLeft, 
  Shield, 
  Bell, 
  Lock, 
  Tag, 
  HelpCircle, 
  LogOut,
  ChevronRight,
  Moon,
  Globe,
  Mail
} from 'lucide-react';
import { Screen } from '../App';
import { Switch } from './ui/switch';

interface SettingsScreenProps {
  navigateTo: (screen: Screen) => void;
  onLogout: () => void;
  userEmail: string;
  loginMethod: 'google' | 'email' | null;
}

export default function SettingsScreen({ navigateTo, onLogout, userEmail, loginMethod }: SettingsScreenProps) {
  const [notifications, setNotifications] = useState(true);
  const [messages, setMessages] = useState(true);
  const [matches, setMatches] = useState(true);
  const [newsletter, setNewsletter] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const handleLogout = () => {
    setShowLogoutConfirm(false);
    onLogout();
  };

  const settingsSections = [
    {
      title: 'Account & Security',
      icon: Shield,
      items: [
        { label: 'Email & Password', icon: Mail, action: () => {} },
        { label: 'Privacy Settings', icon: Lock, action: () => {} },
        { label: 'Two-Factor Auth', icon: Shield, action: () => {} }
      ]
    },
    {
      title: 'Preferences',
      icon: Globe,
      items: [
        { label: 'Dark Mode', icon: Moon, toggle: true, value: true, onChange: () => {} },
        { label: 'Language', icon: Globe, action: () => {} }
      ]
    }
  ];

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#0a0e27] to-[#050811]">
      {/* Header */}
      <div className="px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12 pb-4 sm:pb-6">
        <div className="flex items-center gap-4 mb-6 sm:mb-8">
          <button
            onClick={() => navigateTo('profile')}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors touch-manipulation"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl sm:text-2xl font-bold">Settings</h1>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 pb-24 sm:pb-28 lg:pb-32">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Account & Security */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <h3 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wider flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Account & Security
            </h3>
            <div className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-xl">
              <button className="w-full px-5 py-4 flex items-center justify-between hover:bg-white/5 transition-colors border-b border-white/10">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-[#2dd4bf]" />
                  <span>Email & Password</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
              <button className="w-full px-5 py-4 flex items-center justify-between hover:bg-white/5 transition-colors">
                <div className="flex items-center gap-3">
                  <Lock className="w-5 h-5 text-[#a855f7]" />
                  <span>Privacy Settings</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
            </div>
          </motion.div>

          {/* Notifications */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <h3 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wider flex items-center gap-2">
              <Bell className="w-4 h-4" />
              Notifications
            </h3>
            <div className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-xl">
              <div className="px-5 py-4 flex items-center justify-between border-b border-white/10">
                <div className="flex items-center gap-3">
                  <Bell className="w-5 h-5 text-[#2dd4bf]" />
                  <span>Push Notifications</span>
                </div>
                <Switch checked={notifications} onCheckedChange={setNotifications} />
              </div>
              <div className="px-5 py-4 flex items-center justify-between border-b border-white/10">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-[#a855f7]" />
                  <span>New Messages</span>
                </div>
                <Switch checked={messages} onCheckedChange={setMessages} />
              </div>
              <div className="px-5 py-4 flex items-center justify-between border-b border-white/10">
                <div className="flex items-center gap-3">
                  <Shield className="w-5 h-5 text-[#fb923c]" />
                  <span>New Matches</span>
                </div>
                <Switch checked={matches} onCheckedChange={setMatches} />
              </div>
              <div className="px-5 py-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Globe className="w-5 h-5 text-[#06b6d4]" />
                  <span>Newsletter</span>
                </div>
                <Switch checked={newsletter} onCheckedChange={setNewsletter} />
              </div>
            </div>
          </motion.div>

          {/* Privacy & Safety */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <h3 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wider flex items-center gap-2">
              <Lock className="w-4 h-4" />
              Privacy & Safety
            </h3>
            <div className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-xl">
              <button className="w-full px-5 py-4 flex items-center justify-between hover:bg-white/5 transition-colors border-b border-white/10">
                <div className="flex items-center gap-3">
                  <Lock className="w-5 h-5 text-[#2dd4bf]" />
                  <span>Who can see my profile</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
              <button className="w-full px-5 py-4 flex items-center justify-between hover:bg-white/5 transition-colors">
                <div className="flex items-center gap-3">
                  <Shield className="w-5 h-5 text-[#a855f7]" />
                  <span>Blocked Users</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
            </div>
          </motion.div>

          {/* Interests & Skills */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <h3 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wider flex items-center gap-2">
              <Tag className="w-4 h-4" />
              Interests & Skills
            </h3>
            <div className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-xl">
              <button className="w-full px-5 py-4 flex items-center justify-between hover:bg-white/5 transition-colors">
                <div className="flex items-center gap-3">
                  <Tag className="w-5 h-5 text-[#fb923c]" />
                  <span>Edit Skills & Interests</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
            </div>
          </motion.div>

          {/* Help */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <h3 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wider flex items-center gap-2">
              <HelpCircle className="w-4 h-4" />
              Help & Support
            </h3>
            <div className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-xl">
              <button className="w-full px-5 py-4 flex items-center justify-between hover:bg-white/5 transition-colors border-b border-white/10">
                <div className="flex items-center gap-3">
                  <HelpCircle className="w-5 h-5 text-[#2dd4bf]" />
                  <span>Help Center</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
              <button className="w-full px-5 py-4 flex items-center justify-between hover:bg-white/5 transition-colors border-b border-white/10">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-[#a855f7]" />
                  <span>Contact Support</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
              <button className="w-full px-5 py-4 flex items-center justify-between hover:bg-white/5 transition-colors">
                <div className="flex items-center gap-3">
                  <Shield className="w-5 h-5 text-[#fb923c]" />
                  <span>Terms & Privacy</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
            </div>
          </motion.div>

          {/* Log Out */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <button 
              onClick={() => setShowLogoutConfirm(true)}
              className="w-full bg-gradient-to-r from-red-500/10 to-red-600/10 border border-red-500/30 rounded-2xl px-5 py-4 flex items-center justify-center gap-3 hover:from-red-500/20 hover:to-red-600/20 transition-colors"
            >
              <LogOut className="w-5 h-5 text-red-400" />
              <span className="font-semibold text-red-400">Log Out</span>
            </button>
          </motion.div>

          {showLogoutConfirm && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
              onClick={() => setShowLogoutConfirm(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-[#1a2142] border border-white/10 rounded-2xl overflow-hidden backdrop-blur-xl p-6 text-center max-w-sm w-full"
              >
                <div className="w-16 h-16 mx-auto mb-4 bg-red-500/10 border border-red-500/30 rounded-full flex items-center justify-center">
                  <LogOut className="w-8 h-8 text-red-400" />
                </div>
                <h3 className="text-xl font-bold mb-2">Confirm Logout</h3>
                <p className="text-sm text-gray-400 mb-6">Are you sure you want to log out of your account?</p>
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowLogoutConfirm(false)}
                    className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 font-semibold hover:bg-white/10 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleLogout}
                    className="flex-1 bg-gradient-to-r from-red-500 to-red-600 rounded-xl px-4 py-3 font-semibold hover:opacity-90 transition-opacity"
                  >
                    Log Out
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}

          <div className="text-center text-gray-500 text-sm py-4">
            Version 1.0.0
          </div>
        </div>
      </div>
    </div>
  );
}