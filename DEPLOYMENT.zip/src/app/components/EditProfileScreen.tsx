import { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Camera, Plus, X, Upload, Check } from 'lucide-react';
import { toast } from 'sonner';
import { Screen } from '../App';
import type { UserProfile } from '../App';

interface EditProfileScreenProps {
  navigateTo: (screen: Screen) => void;
  profile: UserProfile;
  updateProfile: (updates: Partial<UserProfile>) => void;
}

const skillOptions = [
  'Design', 'UI/UX', 'Product Management', 'Figma', 'Prototyping', 
  'Web Development', 'React', 'Node.js', 'Python', 'Marketing', 
  'Content Writing', 'Video Editing', 'Photography', 'SEO', 'Data Analysis',
  'Mobile Development', 'DevOps', 'AI/ML', 'Blockchain', 'Sales'
];

const interestOptions = [
  'Cofounder', 'Tech Partner', 'Editor', 'Mentor', 
  'Marketing Partner', 'Designer', 'Developer', 'Content Creator',
  'Investor', 'Advisor', 'Collaborator'
];

export default function EditProfileScreen({ navigateTo, profile, updateProfile }: EditProfileScreenProps) {
  const [name, setName] = useState(profile.name);
  const [bio, setBio] = useState(profile.bio);
  const [location, setLocation] = useState(profile.location);
  const [role, setRole] = useState(profile.role);
  const [selectedSkills, setSelectedSkills] = useState(profile.skills);
  const [selectedInterests, setSelectedInterests] = useState(profile.interests);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const toggleSkill = (skill: string) => {
    if (selectedSkills.includes(skill)) {
      setSelectedSkills(selectedSkills.filter(s => s !== skill));
    } else {
      setSelectedSkills([...selectedSkills, skill]);
    }
  };

  const toggleInterest = (item: string) => {
    if (selectedInterests.includes(item)) {
      setSelectedInterests(selectedInterests.filter(i => i !== item));
    } else {
      setSelectedInterests([...selectedInterests, item]);
    }
  };

  const handleSave = () => {
    // Simulate saving to backend
    const loadingToast = toast.loading('Saving profile changes...');
    
    setTimeout(() => {
      updateProfile({
        name,
        bio,
        location,
        role,
        skills: selectedSkills,
        interests: selectedInterests
      });
      
      toast.dismiss(loadingToast);
      toast.success('Profile updated successfully!', {
        description: 'Your changes have been saved.',
        duration: 3000,
      });
      
      setTimeout(() => {
        navigateTo('profile');
      }, 500);
    }, 1000);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error('Invalid file type', {
        description: 'Please upload an image file (JPG, PNG, or GIF)',
      });
      return;
    }

    // Validate file size (5MB max)
    const maxSize = 5 * 1024 * 1024; // 5MB in bytes
    if (file.size > maxSize) {
      toast.error('File too large', {
        description: 'Please upload an image smaller than 5MB',
      });
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    const reader = new FileReader();
    
    reader.onprogress = (event) => {
      if (event.lengthComputable) {
        const progress = Math.round((event.loaded / event.total) * 100);
        setUploadProgress(progress);
      }
    };
    
    reader.onloadend = () => {
      setTimeout(() => {
        updateProfile({ profilePicture: reader.result as string });
        setIsUploading(false);
        setUploadProgress(0);
        toast.success('Profile picture updated!', {
          description: 'Your new photo looks great!',
        });
      }, 500);
    };

    reader.onerror = () => {
      setIsUploading(false);
      setUploadProgress(0);
      toast.error('Upload failed', {
        description: 'Failed to upload image. Please try again.',
      });
    };

    reader.readAsDataURL(file);
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#0a0e27] to-[#050811]">
      {/* Header */}
      <div className="px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12 pb-4 sm:pb-6 border-b border-white/10">
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigateTo('profile')}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-xl sm:text-2xl font-bold">Edit Profile</h2>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleSave}
            className="px-4 sm:px-6 py-2 bg-gradient-to-r from-[#2dd4bf] to-[#14b8a6] rounded-xl font-semibold text-sm sm:text-base"
          >
            Save
          </motion.button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 pb-24 sm:pb-28 lg:pb-32">
        <div className="max-w-4xl mx-auto py-4 sm:py-6 space-y-6">
          {/* Profile Photo */}
          <div className="flex flex-col items-center gap-3 sm:gap-4">
            <div className="relative">
              {profile.profilePicture ? (
                <img
                  src={profile.profilePicture}
                  alt={profile.name}
                  className="w-24 h-24 sm:w-28 sm:h-28 md:w-32 md:h-32 rounded-2xl sm:rounded-3xl object-cover shadow-lg"
                />
              ) : (
                <div className="w-24 h-24 sm:w-28 sm:h-28 md:w-32 md:h-32 rounded-2xl sm:rounded-3xl bg-gradient-to-br from-[#2dd4bf] to-[#a855f7] flex items-center justify-center text-3xl sm:text-4xl font-bold shadow-lg">
                  {profile.initials}
                </div>
              )}
              
              {isUploading && (
                <div className="absolute inset-0 rounded-2xl sm:rounded-3xl bg-black/60 backdrop-blur-sm flex items-center justify-center">
                  <div className="text-center">
                    <Upload className="w-8 h-8 mx-auto mb-2 animate-pulse text-[#2dd4bf]" />
                    <p className="text-sm font-semibold">{uploadProgress}%</p>
                  </div>
                </div>
              )}
              
              <motion.button
                whileTap={{ scale: 0.95 }}
                whileHover={{ scale: 1.05 }}
                disabled={isUploading}
                className="absolute bottom-0 right-0 w-9 h-9 sm:w-10 sm:h-10 bg-gradient-to-r from-[#fb923c] to-[#f97316] rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow touch-manipulation disabled:opacity-50"
                onClick={() => fileInputRef.current?.click()}
              >
                <Camera className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
              </motion.button>
              <input
                type="file"
                accept="image/*"
                ref={fileInputRef}
                className="hidden"
                onChange={handleFileChange}
                disabled={isUploading}
              />
            </div>
            <div className="text-center">
              <p className="text-xs sm:text-sm text-gray-400">Tap camera icon to change photo</p>
              <p className="text-[10px] sm:text-xs text-gray-500 mt-1">JPG, PNG or GIF • Max 5MB</p>
            </div>
          </div>

          {/* Form Fields */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left Column */}
            <div className="space-y-6">
              {/* Name */}
              <div>
                <label className="block text-sm font-semibold text-gray-400 mb-2">Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full h-12 px-4 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#2dd4bf] transition-colors"
                />
              </div>

              {/* Bio */}
              <div>
                <label className="block text-sm font-semibold text-gray-400 mb-2">Bio</label>
                <textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  rows={3}
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#2dd4bf] transition-colors resize-none"
                />
              </div>

              {/* Location */}
              <div>
                <label className="block text-sm font-semibold text-gray-400 mb-2">Location</label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full h-12 px-4 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#2dd4bf] transition-colors"
                />
              </div>

              {/* Role */}
              <div>
                <label className="block text-sm font-semibold text-gray-400 mb-2">Role</label>
                <input
                  type="text"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full h-12 px-4 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#2dd4bf] transition-colors"
                />
              </div>
            </div>

            {/* Right Column */}
            <div className="space-y-6">
              {/* Skills */}
              <div>
                <label className="block text-sm font-semibold text-gray-400 mb-3">Skills ({selectedSkills.length} selected)</label>
                <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto p-4 bg-white/5 border border-white/10 rounded-xl">
                  {skillOptions.map((skill) => (
                    <motion.button
                      key={skill}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => toggleSkill(skill)}
                      className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                        selectedSkills.includes(skill)
                          ? 'bg-gradient-to-r from-[#2dd4bf] to-[#14b8a6] text-white'
                          : 'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10'
                      }`}
                    >
                      {skill}
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Interests */}
              <div>
                <label className="block text-sm font-semibold text-gray-400 mb-3">Interests ({selectedInterests.length} selected)</label>
                <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto p-4 bg-white/5 border border-white/10 rounded-xl">
                  {interestOptions.map((item) => (
                    <motion.button
                      key={item}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => toggleInterest(item)}
                      className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                        selectedInterests.includes(item)
                          ? 'bg-gradient-to-r from-[#a855f7] to-[#9333ea] text-white'
                          : 'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10'
                      }`}
                    >
                      {item}
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Additional Info Section for larger screens */}
          <div className="hidden lg:block space-y-4 pt-6 border-t border-white/10">
            <h3 className="text-lg font-bold mb-4">Additional Information</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-400 mb-2">Website</label>
                <input
                  type="url"
                  placeholder="https://yourwebsite.com"
                  className="w-full h-12 px-4 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#2dd4bf] transition-colors"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-400 mb-2">LinkedIn</label>
                <input
                  type="url"
                  placeholder="linkedin.com/in/username"
                  className="w-full h-12 px-4 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#2dd4bf] transition-colors"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}