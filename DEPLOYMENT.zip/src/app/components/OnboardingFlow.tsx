import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, Check } from 'lucide-react';

interface OnboardingFlowProps {
  onComplete: () => void;
}

const ageGroups = ['12-17', '18-24', '25-34', '35-44', '45-50'];
const skillsList = [
  'Design', 'Development', 'Marketing', 'Sales', 'Product',
  'Finance', 'Operations', 'Content', 'Analytics', 'AI/ML'
];
const stages = ['Idea', 'MVP', 'Early Revenue', 'Scaling', 'Not Started'];
const lookingFor = ['Cofounder', 'Tech Partner', 'Editor', 'Mentor', 'Investor'];

export default function OnboardingFlow({ onComplete }: OnboardingFlowProps) {
  const [step, setStep] = useState(0);
  const [ageGroup, setAgeGroup] = useState('');
  const [city, setCity] = useState('');
  const [skills, setSkills] = useState<string[]>([]);
  const [stage, setStage] = useState('');
  const [seeking, setSeeking] = useState<string[]>([]);

  const totalSteps = 5;
  const progress = ((step + 1) / totalSteps) * 100;

  const handleNext = () => {
    if (step < totalSteps - 1) {
      setStep(step + 1);
    } else {
      onComplete();
    }
  };

  const toggleSelection = (value: string, array: string[], setter: (arr: string[]) => void) => {
    if (array.includes(value)) {
      setter(array.filter(v => v !== value));
    } else {
      setter([...array, value]);
    }
  };

  const canProceed = () => {
    switch (step) {
      case 0: return ageGroup !== '';
      case 1: return city.trim() !== '';
      case 2: return skills.length > 0;
      case 3: return stage !== '';
      case 4: return seeking.length > 0;
      default: return false;
    }
  };

  return (
    <div className="h-full flex flex-col px-6 py-8">
      {/* Progress Bar */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-gray-400">Step {step + 1} of {totalSteps}</span>
          <span className="text-sm font-semibold text-[#2dd4bf]">{Math.round(progress)}%</span>
        </div>
        <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-[#2dd4bf] to-[#a855f7]"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          />
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            {step === 0 && (
              <div>
                <h2 className="text-3xl font-bold mb-2">How old are you?</h2>
                <p className="text-gray-400 mb-8">Help us personalize your experience</p>
                <div className="grid grid-cols-2 gap-3">
                  {ageGroups.map((age) => (
                    <button
                      key={age}
                      onClick={() => setAgeGroup(age)}
                      className={`h-14 rounded-2xl font-semibold transition-all duration-300 ${
                        ageGroup === age
                          ? 'bg-gradient-to-r from-[#2dd4bf] to-[#a855f7] text-white shadow-lg'
                          : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/10'
                      }`}
                    >
                      {age}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 1 && (
              <div>
                <h2 className="text-3xl font-bold mb-2">Where are you based?</h2>
                <p className="text-gray-400 mb-8">Connect with people nearby</p>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="Enter your city"
                  className="w-full h-14 px-5 bg-white/5 border border-white/10 rounded-2xl text-white placeholder-gray-500 focus:outline-none focus:border-[#2dd4bf] transition-colors"
                />
              </div>
            )}

            {step === 2 && (
              <div>
                <h2 className="text-3xl font-bold mb-2">Your skills</h2>
                <p className="text-gray-400 mb-8">Select all that apply</p>
                <div className="flex flex-wrap gap-2">
                  {skillsList.map((skill) => (
                    <button
                      key={skill}
                      onClick={() => toggleSelection(skill, skills, setSkills)}
                      className={`px-5 py-3 rounded-full font-medium transition-all duration-300 ${
                        skills.includes(skill)
                          ? 'bg-gradient-to-r from-[#2dd4bf] to-[#a855f7] text-white shadow-lg'
                          : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/10'
                      }`}
                    >
                      {skill}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 3 && (
              <div>
                <h2 className="text-3xl font-bold mb-2">Startup stage</h2>
                <p className="text-gray-400 mb-8">Where are you at?</p>
                <div className="space-y-3">
                  {stages.map((s) => (
                    <button
                      key={s}
                      onClick={() => setStage(s)}
                      className={`w-full h-14 rounded-2xl font-semibold transition-all duration-300 flex items-center justify-between px-5 ${
                        stage === s
                          ? 'bg-gradient-to-r from-[#2dd4bf] to-[#a855f7] text-white shadow-lg'
                          : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/10'
                      }`}
                    >
                      <span>{s}</span>
                      {stage === s && <Check className="w-5 h-5" />}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 4 && (
              <div>
                <h2 className="text-3xl font-bold mb-2">I'm looking for</h2>
                <p className="text-gray-400 mb-8">What brings you here?</p>
                <div className="flex flex-wrap gap-3">
                  {lookingFor.map((item) => (
                    <button
                      key={item}
                      onClick={() => toggleSelection(item, seeking, setSeeking)}
                      className={`px-6 py-4 rounded-2xl font-semibold transition-all duration-300 ${
                        seeking.includes(item)
                          ? 'bg-gradient-to-r from-[#2dd4bf] to-[#a855f7] text-white shadow-lg'
                          : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/10'
                      }`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Next Button */}
      <motion.button
        onClick={handleNext}
        disabled={!canProceed()}
        whileTap={{ scale: 0.98 }}
        className={`w-full h-14 rounded-2xl font-semibold flex items-center justify-center gap-2 mt-6 transition-all duration-300 ${
          canProceed()
            ? 'bg-gradient-to-r from-[#fb923c] to-[#f97316] text-white shadow-lg hover:shadow-xl'
            : 'bg-gray-800 text-gray-500 cursor-not-allowed'
        }`}
      >
        {step === totalSteps - 1 ? "Let's Go!" : 'Continue'}
        <ChevronRight className="w-5 h-5" />
      </motion.button>
    </div>
  );
}
