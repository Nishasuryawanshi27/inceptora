import { motion } from 'motion/react';
import { ArrowLeft, Heart, MessageCircle, UserPlus, Calendar, TrendingUp } from 'lucide-react';
import { Screen } from '../App';

interface NotificationsScreenProps {
  navigateTo: (screen: Screen) => void;
}

const notifications = [
  {
    id: 1,
    type: 'match',
    icon: Heart,
    color: 'text-[#fb923c]',
    bgColor: 'bg-[#fb923c]/20',
    borderColor: 'border-[#fb923c]/50',
    title: 'New Match!',
    message: 'You matched with Sarah Chen (95% compatibility)',
    time: '5 minutes ago',
    unread: true,
  },
  {
    id: 2,
    type: 'message',
    icon: MessageCircle,
    color: 'text-[#2dd4bf]',
    bgColor: 'bg-[#2dd4bf]/20',
    borderColor: 'border-[#2dd4bf]/50',
    title: 'New Message',
    message: 'Alex Kumar sent you a message',
    time: '1 hour ago',
    unread: true,
  },
  {
    id: 3,
    type: 'event',
    icon: Calendar,
    color: 'text-[#a855f7]',
    bgColor: 'bg-[#a855f7]/20',
    borderColor: 'border-[#a855f7]/50',
    title: 'Event Reminder',
    message: 'Startup Networking Session starts in 2 hours',
    time: '2 hours ago',
    unread: true,
  },
  {
    id: 4,
    type: 'connection',
    icon: UserPlus,
    color: 'text-[#2dd4bf]',
    bgColor: 'bg-[#2dd4bf]/20',
    borderColor: 'border-[#2dd4bf]/50',
    title: 'New Connection',
    message: 'Maya Patel accepted your connection request',
    time: '3 hours ago',
    unread: false,
  },
  {
    id: 5,
    type: 'activity',
    icon: TrendingUp,
    color: 'text-[#fb923c]',
    bgColor: 'bg-[#fb923c]/20',
    borderColor: 'border-[#fb923c]/50',
    title: 'Profile Views',
    message: 'Your profile got 12 views this week',
    time: '1 day ago',
    unread: false,
  },
];

export default function NotificationsScreen({ navigateTo }: NotificationsScreenProps) {
  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#0a0e27] to-[#050811]">
      {/* Header */}
      <div className="px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12 pb-4 sm:pb-6">
        <div className="flex items-center justify-between mb-4 sm:mb-6">
          <button
            onClick={() => navigateTo('feed')}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors touch-manipulation"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-lg sm:text-xl font-bold">Notifications</h2>
          <button className="px-3 sm:px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-xs sm:text-sm hover:bg-white/10 transition-colors">
            Mark all read
          </button>
        </div>
      </div>

      {/* Notifications List */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 pb-24 sm:pb-28 lg:pb-32">
        <div className="max-w-4xl mx-auto space-y-3">
          {notifications.map((notification, index) => {
            const Icon = notification.icon;
            return (
              <motion.div
                key={notification.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`bg-gradient-to-br from-white/5 to-white/[0.02] border ${
                  notification.unread ? 'border-white/20' : 'border-white/10'
                } rounded-2xl p-4 backdrop-blur-xl hover:border-white/30 transition-colors cursor-pointer`}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-xl ${notification.bgColor} border ${notification.borderColor} flex items-center justify-center flex-shrink-0`}>
                    <Icon className={`w-6 h-6 ${notification.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-1">
                      <h4 className="font-semibold text-white">{notification.title}</h4>
                      {notification.unread && (
                        <span className="w-2 h-2 bg-[#fb923c] rounded-full flex-shrink-0 mt-1.5" />
                      )}
                    </div>
                    <p className="text-sm text-gray-400 mb-2">{notification.message}</p>
                    <span className="text-xs text-gray-500">{notification.time}</span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}