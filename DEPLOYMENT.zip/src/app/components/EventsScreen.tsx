import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Calendar, MapPin, Users, Clock, Star, Filter } from 'lucide-react';
import { Screen } from '../App';

interface EventsScreenProps {
  navigateTo: (screen: Screen) => void;
}

type EventTab = 'upcoming' | 'registered' | 'past';

const events = [
  {
    id: 1,
    title: 'Startup Networking Session',
    date: 'Dec 15, 2025',
    time: '6:00 PM - 8:00 PM',
    location: 'Virtual Event',
    attendees: 45,
    category: 'Networking',
    gradient: 'from-[#2dd4bf] to-[#14b8a6]',
    registered: true,
  },
  {
    id: 2,
    title: 'Product Design Workshop',
    date: 'Dec 18, 2025',
    time: '3:00 PM - 5:00 PM',
    location: 'San Francisco, CA',
    attendees: 32,
    category: 'Workshop',
    gradient: 'from-[#a855f7] to-[#9333ea]',
    registered: false,
  },
  {
    id: 3,
    title: 'Founder Meetup: SaaS Edition',
    date: 'Dec 20, 2025',
    time: '7:00 PM - 9:00 PM',
    location: 'New York, NY',
    attendees: 67,
    category: 'Meetup',
    gradient: 'from-[#fb923c] to-[#f97316]',
    registered: true,
  },
  {
    id: 4,
    title: 'AI/ML for Beginners',
    date: 'Dec 22, 2025',
    time: '2:00 PM - 4:00 PM',
    location: 'Virtual Event',
    attendees: 128,
    category: 'Workshop',
    gradient: 'from-[#06b6d4] to-[#0891b2]',
    registered: false,
  },
];

export default function EventsScreen({ navigateTo }: EventsScreenProps) {
  const [activeTab, setActiveTab] = useState<EventTab>('upcoming');
  const [showFilter, setShowFilter] = useState(false);
  const [activeFilter, setActiveFilter] = useState('All');

  const tabs = [
    { id: 'upcoming' as EventTab, label: 'Upcoming' },
    { id: 'registered' as EventTab, label: 'Registered' },
    { id: 'past' as EventTab, label: 'Past' },
  ];

  const filteredEvents = activeTab === 'registered' 
    ? events.filter(e => e.registered)
    : events;

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#0a0e27] to-[#050811]">
      {/* Header */}
      <div className="px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12 pb-4 sm:pb-6">
        <div className="flex items-center justify-between mb-4 sm:mb-6">
          <button
            onClick={() => navigateTo('feed')}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors touch-manipulation"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-lg sm:text-xl font-bold">Events</h2>
          <button
            onClick={() => setShowFilter(!showFilter)}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors touch-manipulation"
          >
            <Filter className={`w-5 h-5 ${showFilter ? 'text-[#2dd4bf]' : ''}`} />
          </button>
        </div>

        {/* Filter Pills */}
        {showFilter && (
          <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
            {['All', 'Networking', 'Workshop', 'Conference', 'Meetup'].map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-3 sm:px-4 py-2 rounded-full font-medium text-xs sm:text-sm whitespace-nowrap transition-all ${
                  activeFilter === filter
                    ? 'bg-gradient-to-r from-[#2dd4bf] to-[#a855f7] text-white shadow-lg'
                    : 'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Events List */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 pb-24 sm:pb-28 lg:pb-32">
        <div className="max-w-4xl mx-auto space-y-4">
          {filteredEvents.map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-gradient-to-br from-white/10 to-white/[0.02] border border-white/20 rounded-3xl p-5 backdrop-blur-xl hover:border-white/30 transition-colors"
            >
              {/* Event Category Badge */}
              <div className="flex items-start justify-between mb-4">
                <span className={`px-3 py-1 bg-gradient-to-r ${event.gradient} rounded-full text-xs font-bold`}>
                  {event.category}
                </span>
                {event.registered && (
                  <div className="flex items-center gap-1 px-3 py-1 bg-[#2dd4bf]/20 border border-[#2dd4bf]/50 rounded-full">
                    <Star className="w-3 h-3 text-[#2dd4bf] fill-[#2dd4bf]" />
                    <span className="text-xs text-[#2dd4bf] font-medium">Registered</span>
                  </div>
                )}
              </div>

              {/* Event Title */}
              <h3 className="text-xl font-bold mb-3">{event.title}</h3>

              {/* Event Details */}
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-gray-400">
                  <Calendar className="w-4 h-4" />
                  <span className="text-sm">{event.date}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-400">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm">{event.time}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-400">
                  <MapPin className="w-4 h-4" />
                  <span className="text-sm">{event.location}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-400">
                  <Users className="w-4 h-4" />
                  <span className="text-sm">{event.attendees} attendees</span>
                </div>
              </div>

              {/* Action Button */}
              <motion.button
                whileTap={{ scale: 0.98 }}
                className={`w-full h-12 rounded-xl font-semibold transition-all ${
                  event.registered
                    ? 'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10'
                    : 'bg-gradient-to-r from-[#fb923c] to-[#f97316] text-white shadow-lg'
                }`}
              >
                {event.registered ? 'View Details' : 'Register Now'}
              </motion.button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}