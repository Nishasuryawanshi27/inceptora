import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, Users, MessageCircle, Sparkles } from 'lucide-react';
import logo from 'figma:asset/589d6572b6c8eee2261523f1185cc1a693f70dd0.png';

interface WalkthroughScreenProps {
  onComplete: () => void;
}

const slides = [
  {
    icon: Users,
    title: 'Find Your Perfect Match',
    description: 'Connect with cofounders, tech partners, editors, and mentors who share your vision and passion.',
    gradient: 'from-[#2dd4bf] to-[#14b8a6]',
  },
  {
    icon: MessageCircle,
    title: 'Community & Networking',
    description: 'Join community chats, attend exclusive events, and collaborate with creators worldwide.',
    gradient: 'from-[#a855f7] to-[#9333ea]',
  },
  {
    icon: Sparkles,
    title: 'Start Your Journey',
    description: 'Whether you\'re 12 or 50, Inceptora helps you build something amazing together.',
    gradient: 'from-[#fb923c] to-[#f97316]',
  },
];

export default function WalkthroughScreen({ onComplete }: WalkthroughScreenProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      onComplete();
    }
  };

  const skipWalkthrough = () => {
    onComplete();
  };

  const slide = slides[currentSlide];
  const Icon = slide.icon;
  const isLastSlide = currentSlide === slides.length - 1;

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#0a0e27] to-[#050811] relative overflow-hidden">
      {/* Ambient glow effects */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-[#2dd4bf] opacity-20 blur-[150px] rounded-full animate-pulse" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-[#a855f7] opacity-20 blur-[150px] rounded-full animate-pulse" style={{ animationDelay: '1s' }} />

      {/* Skip button */}
      {!isLastSlide && (
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={skipWalkthrough}
          className="absolute top-12 right-6 px-4 py-2 text-gray-400 hover:text-white transition-colors z-10"
        >
          Skip
        </motion.button>
      )}

      {/* Logo */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="pt-16 pb-8 flex justify-center"
      >
        <img src={logo} alt="Inceptora" className="h-16 w-16" />
      </motion.div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="flex flex-col items-center text-center"
          >
            {/* Icon */}
            <motion.div
              className={`w-24 h-24 rounded-3xl bg-gradient-to-br ${slide.gradient} flex items-center justify-center mb-8 shadow-2xl`}
              animate={{
                scale: [1, 1.05, 1],
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Icon className="w-12 h-12 text-white" strokeWidth={2} />
            </motion.div>

            {/* Title */}
            <h2 className="text-3xl font-bold mb-4 px-4">
              {slide.title}
            </h2>

            {/* Description */}
            <p className="text-gray-400 text-lg leading-relaxed max-w-sm">
              {slide.description}
            </p>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Progress indicators */}
      <div className="flex justify-center gap-2 mb-8">
        {slides.map((_, index) => (
          <motion.div
            key={index}
            className={`h-1.5 rounded-full transition-all duration-300 ${
              index === currentSlide
                ? 'w-8 bg-gradient-to-r from-[#2dd4bf] to-[#a855f7]'
                : 'w-1.5 bg-white/20'
            }`}
          />
        ))}
      </div>

      {/* Next/Get Started button */}
      <div className="px-8 pb-12">
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={nextSlide}
          className="w-full h-14 bg-gradient-to-r from-[#fb923c] to-[#f97316] rounded-2xl font-bold text-lg shadow-2xl shadow-[#fb923c]/30 flex items-center justify-center gap-2"
        >
          {isLastSlide ? 'Get Started' : 'Next'}
          <ChevronRight className="w-5 h-5" />
        </motion.button>
      </div>
    </div>
  );
}