import { useState } from 'react';
import { motion } from 'motion/react';
import { X, Image, Hash } from 'lucide-react';
import { Screen } from '../App';

interface CreatePostScreenProps {
  navigateTo: (screen: Screen) => void;
}

const postTypes = [
  { id: 'cofounder', label: 'Looking for Cofounder', gradient: 'from-[#2dd4bf] to-[#14b8a6]' },
  { id: 'feedback', label: 'Feedback on Idea', gradient: 'from-[#a855f7] to-[#9333ea]' },
  { id: 'mentor', label: 'Seeking Mentor', gradient: 'from-[#fb923c] to-[#f97316]' },
  { id: 'offering', label: 'Offering Help', gradient: 'from-[#06b6d4] to-[#0891b2]' },
];

const suggestedTags = ['Design', 'Development', 'Marketing', 'AI/ML', 'SaaS', 'B2B', 'Startup'];

export default function CreatePostScreen({ navigateTo }: CreatePostScreenProps) {
  const [selectedType, setSelectedType] = useState('');
  const [content, setContent] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter(t => t !== tag));
    } else {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  const handlePost = () => {
    // Post logic here
    navigateTo('feed');
  };

  const canPost = selectedType && content.trim().length > 0;

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#0a0e27] to-[#050811]">
      {/* Header */}
      <div className="px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12 pb-4 sm:pb-6">
        <div className="flex items-center justify-between mb-4 sm:mb-6">
          <button
            onClick={() => navigateTo('feed')}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors touch-manipulation"
          >
            <X className="w-5 h-5" />
          </button>
          <h2 className="text-lg sm:text-xl font-bold">Create Post</h2>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => navigateTo('feed')}
            className="px-4 py-2 bg-gradient-to-r from-[#2dd4bf] to-[#14b8a6] rounded-xl font-semibold text-sm hover:opacity-90 transition-opacity"
          >
            Post
          </motion.button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 pb-24 sm:pb-28 lg:pb-32">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Post Type Selection */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wider">
              What are you posting about?
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {postTypes.map((type) => (
                <motion.button
                  key={type.id}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setSelectedType(type.id)}
                  className={`h-20 rounded-2xl font-semibold transition-all relative overflow-hidden ${
                    selectedType === type.id
                      ? 'shadow-lg'
                      : 'bg-white/5 border border-white/10 hover:bg-white/10'
                  }`}
                >
                  {selectedType === type.id && (
                    <div className={`absolute inset-0 bg-gradient-to-br ${type.gradient}`} />
                  )}
                  <span className="relative z-10">{type.label}</span>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Content Input */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wider">
              Write your post
            </h3>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Share your thoughts, ideas, or what you're looking for..."
              className="w-full h-40 px-5 py-4 bg-white/5 border border-white/10 rounded-2xl text-white placeholder-gray-500 focus:outline-none focus:border-[#2dd4bf] transition-colors resize-none"
              maxLength={500}
            />
            <div className="flex justify-between items-center mt-2">
              <span className="text-xs text-gray-500">{content.length}/500</span>
              <div className="flex gap-2">
                <button className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors">
                  <Image className="w-4 h-4 text-gray-400" />
                </button>
              </div>
            </div>
          </div>

          {/* Tags */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wider flex items-center gap-2">
              <Hash className="w-4 h-4" />
              Add tags
            </h3>
            <div className="flex flex-wrap gap-2">
              {suggestedTags.map((tag) => (
                <motion.button
                  key={tag}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => toggleTag(tag)}
                  className={`px-4 py-2 rounded-full font-medium text-sm transition-all ${
                    selectedTags.includes(tag)
                      ? 'bg-gradient-to-r from-[#2dd4bf] to-[#a855f7] text-white shadow-lg'
                      : 'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10'
                  }`}
                >
                  {tag}
                </motion.button>
              ))}
            </div>
          </div>

          {/* Preview */}
          {selectedType && content && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-6"
            >
              <h3 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wider">
                Preview
              </h3>
              <div className="bg-gradient-to-br from-white/10 to-white/[0.02] border border-white/20 rounded-3xl p-5 backdrop-blur-xl">
                <div className="flex items-start gap-3 mb-4">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#2dd4bf] to-[#a855f7] flex items-center justify-center text-xl font-bold">
                    JD
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold">John Doe</h4>
                    <p className="text-xs text-gray-400">Just now</p>
                  </div>
                  <span className="px-3 py-1 bg-gradient-to-r from-[#fb923c]/20 to-[#f97316]/20 border border-[#fb923c]/50 rounded-full text-xs font-medium">
                    {postTypes.find(t => t.id === selectedType)?.label}
                  </span>
                </div>
                <p className="text-gray-300 mb-4">{content}</p>
                {selectedTags.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {selectedTags.map((tag) => (
                      <span key={tag} className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-xs">
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}