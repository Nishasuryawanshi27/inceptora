import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Plus, Heart, MessageCircle, Bookmark, Bell, Calendar, ArrowRight, ArrowUpDown } from 'lucide-react';
import { Screen } from '../App';

interface FeedScreenProps {
  navigateTo: (screen: Screen) => void;
}

const posts = [
  {
    id: 1,
    author: 'Emma Rodriguez',
    avatar: '🎨',
    time: '2h ago',
    type: 'Looking for Cofounder',
    content: 'Seeking a technical cofounder for an AI-powered design tool. Must have experience with React and ML. DM if interested!',
    tags: ['Design', 'AI/ML', 'Cofounder'],
    likes: 24,
    comments: 8,
    saved: false,
    liked: false
  },
  {
    id: 2,
    author: 'James Chen',
    avatar: '💻',
    time: '5h ago',
    type: 'Feedback on Idea',
    content: 'Working on a B2B SaaS for project management. Would love feedback on the MVP I just built!',
    tags: ['B2B', 'SaaS', 'Feedback'],
    likes: 18,
    comments: 12,
    saved: false,
    liked: false
  },
  {
    id: 3,
    author: 'Priya Sharma',
    avatar: '📈',
    time: '1d ago',
    type: 'Offering Help',
    content: 'Happy to mentor early-stage founders on growth and marketing. 10+ years experience scaling startups. Reach out!',
    tags: ['Marketing', 'Mentor', 'Growth'],
    likes: 42,
    comments: 15,
    saved: false,
    liked: false
  }
];

export default function FeedScreen({ navigateTo }: FeedScreenProps) {
  const [feedPosts, setFeedPosts] = useState(posts);
  const [sortBy, setSortBy] = useState<'recent' | 'popular' | 'trending'>('recent');
  const [showSortMenu, setShowSortMenu] = useState(false);

  const toggleLike = (id: number) => {
    setFeedPosts(feedPosts.map(post => 
      post.id === id 
        ? { ...post, liked: !post.liked, likes: post.liked ? post.likes - 1 : post.likes + 1 }
        : post
    ));
  };

  const toggleSave = (id: number) => {
    setFeedPosts(feedPosts.map(post => 
      post.id === id 
        ? { ...post, saved: !post.saved }
        : post
    ));
  };

  const handleSort = (type: 'recent' | 'popular' | 'trending') => {
    setSortBy(type);
    setShowSortMenu(false);
    // In a real app, you would sort the feedPosts here
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#0a0e27] to-[#050811]">
      {/* Header */}
      <div className="px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12 pb-4">
        <div className="flex items-center justify-between mb-4 sm:mb-6">
          <button
            onClick={() => navigateTo('home')}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors touch-manipulation"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-lg sm:text-xl font-bold">Community Feed</h2>
          <div className="flex items-center gap-2">
            <motion.button 
              whileTap={{ scale: 0.9 }}
              whileHover={{ scale: 1.05 }}
              onClick={() => navigateTo('events')}
              className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors relative touch-manipulation"
            >
              <Calendar className="w-5 h-5 text-[#a855f7]" strokeWidth={2} />
            </motion.button>
            <motion.button 
              whileTap={{ scale: 0.9 }}
              whileHover={{ scale: 1.05 }}
              onClick={() => navigateTo('notifications')}
              className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors relative touch-manipulation"
            >
              <Bell className="w-5 h-5 text-[#2dd4bf]" strokeWidth={2} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-[#fb923c] rounded-full border border-[#0a0e27]" />
            </motion.button>
          </div>
        </div>

        {/* Filter Pills and Sort */}
        <div className="flex items-center justify-between gap-3 mb-2">
          <div className="flex gap-2 overflow-x-auto flex-1 no-scrollbar">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => navigateTo('community')}
              className="px-3 sm:px-4 py-2 rounded-full font-medium text-xs sm:text-sm whitespace-nowrap transition-all bg-gradient-to-r from-[#06b6d4] to-[#0891b2] text-white shadow-lg flex items-center gap-1.5 sm:gap-2"
            >
              <MessageCircle className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">Community Chats</span>
              <span className="sm:hidden">Chats</span>
            </motion.button>
            {['All', 'Cofounder', 'Feedback', 'Mentor', 'Ideas'].map((filter) => (
              <button
                key={filter}
                className={`px-3 sm:px-4 py-2 rounded-full font-medium text-xs sm:text-sm whitespace-nowrap transition-colors ${
                  filter === 'All'
                    ? 'bg-gradient-to-r from-[#2dd4bf] to-[#a855f7] text-white'
                    : 'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
          
          {/* Sort Dropdown */}
          <div className="relative flex-shrink-0">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowSortMenu(!showSortMenu)}
              className="flex items-center gap-1.5 px-3 sm:px-4 py-2 bg-white/5 border border-white/10 rounded-full hover:bg-white/10 transition-colors"
            >
              <ArrowUpDown className="w-3 h-3 sm:w-4 sm:h-4 text-[#2dd4bf]" />
              <span className="text-xs sm:text-sm font-medium capitalize hidden sm:inline">{sortBy}</span>
            </motion.button>

            {showSortMenu && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute right-0 top-full mt-2 w-40 sm:w-48 bg-[#1a2142] border border-white/10 rounded-2xl p-2 shadow-2xl backdrop-blur-xl z-10"
              >
                {[
                  { value: 'recent', label: '🕐 Recent', description: 'Latest posts' },
                  { value: 'popular', label: '🔥 Popular', description: 'Most liked' },
                  { value: 'trending', label: '📈 Trending', description: 'Most active' }
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => handleSort(option.value as 'recent' | 'popular' | 'trending')}
                    className={`w-full text-left px-3 py-2.5 sm:py-3 rounded-xl transition-colors ${
                      sortBy === option.value
                        ? 'bg-gradient-to-r from-[#2dd4bf]/20 to-[#a855f7]/20 border border-[#2dd4bf]/50'
                        : 'hover:bg-white/5'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm sm:text-base">{option.label}</span>
                    </div>
                    <p className="text-[10px] sm:text-xs text-gray-400 mt-0.5">{option.description}</p>
                  </button>
                ))}
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* Posts Feed */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 pb-24 sm:pb-28 lg:pb-32">
        <div className="max-w-4xl mx-auto">
          {/* Community Chat Highlight Card */}
          <motion.button
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={() => navigateTo('community')}
            className="w-full mb-4 bg-gradient-to-br from-[#06b6d4]/20 to-[#0891b2]/10 border border-[#06b6d4]/30 rounded-3xl p-5 backdrop-blur-xl hover:border-[#06b6d4]/50 transition-colors"
          >
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#06b6d4] to-[#0891b2] flex items-center justify-center text-2xl shadow-lg">
                💬
              </div>
              <div className="flex-1 text-left">
                <h3 className="font-bold text-white mb-1">Join Community Chats</h3>
                <p className="text-sm text-gray-300">Connect with 6+ active communities</p>
              </div>
              <ArrowRight className="w-5 h-5 text-[#06b6d4]" />
            </div>
          </motion.button>

          <div className="space-y-4">
            {feedPosts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-gradient-to-br from-white/10 to-white/[0.02] border border-white/20 rounded-3xl p-5 backdrop-blur-xl"
              >
                {/* Post Header */}
                <div className="flex items-start gap-3 mb-4">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#2dd4bf] to-[#a855f7] flex items-center justify-center text-xl">
                    {post.avatar}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold">{post.author}</h4>
                    <p className="text-xs text-gray-400">{post.time}</p>
                  </div>
                  <span className="px-3 py-1 bg-gradient-to-r from-[#fb923c]/20 to-[#f97316]/20 border border-[#fb923c]/50 rounded-full text-xs font-medium">
                    {post.type}
                  </span>
                </div>

                {/* Post Content */}
                <p className="text-gray-300 mb-4 leading-relaxed">{post.content}</p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {post.tags.map((tag) => (
                    <span key={tag} className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-xs">
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-6 pt-4 border-t border-white/10">
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => toggleLike(post.id)}
                    className="flex items-center gap-2 text-gray-400 hover:text-[#fb923c] transition-colors"
                  >
                    <Heart className={`w-5 h-5 ${post.liked ? 'fill-[#fb923c] text-[#fb923c]' : ''}`} />
                    <span className="text-sm font-medium">{post.likes}</span>
                  </motion.button>

                  <button className="flex items-center gap-2 text-gray-400 hover:text-[#2dd4bf] transition-colors">
                    <MessageCircle className="w-5 h-5" />
                    <span className="text-sm font-medium">{post.comments}</span>
                  </button>

                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => toggleSave(post.id)}
                    className="ml-auto text-gray-400 hover:text-[#a855f7] transition-colors"
                  >
                    <Bookmark className={`w-5 h-5 ${post.saved ? 'fill-[#a855f7] text-[#a855f7]' : ''}`} />
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}