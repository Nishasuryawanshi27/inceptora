import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Settings, Edit2, Calendar, Bell, Users, Star, Award, Activity, Heart, MapPin, Briefcase } from 'lucide-react';
import { Screen } from '../App';
import type { UserProfile } from '../App';

interface ProfileScreenProps {
  navigateTo: (screen: Screen) => void;
  profile: UserProfile;
}

type Tab = 'overview' | 'saved' | 'liked' | 'activity';

export default function ProfileScreen({ navigateTo, profile }: ProfileScreenProps) {
  const [activeTab, setActiveTab] = useState<Tab>('overview');

  const tabs = [
    { id: 'overview' as Tab, label: 'Overview', icon: Users },
    { id: 'saved' as Tab, label: 'Saved', icon: Star },
    { id: 'liked' as Tab, label: 'Liked', icon: Award },
    { id: 'activity' as Tab, label: 'Activity', icon: Activity },
  ];

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#0a0e27] to-[#050811]">
      {/* Header */}
      <div className="px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12 pb-4">
        <div className="flex items-center justify-between mb-4 sm:mb-6">
          <button
            onClick={() => navigateTo('feed')}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-xl sm:text-2xl font-bold">Profile</h2>
          <div className="flex items-center gap-1 sm:gap-2">
            <motion.button
              whileTap={{ scale: 0.9 }}
              whileHover={{ scale: 1.05 }}
              onClick={() => navigateTo('settings')}
              className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors"
            >
              <Settings className="w-5 h-5 text-gray-300" strokeWidth={2} />
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.9 }}
              whileHover={{ scale: 1.05 }}
              onClick={() => navigateTo('events')}
              className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors relative hidden lg:flex"
            >
              <Calendar className="w-5 h-5 text-[#a855f7]" strokeWidth={2} />
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.9 }}
              whileHover={{ scale: 1.05 }}
              onClick={() => navigateTo('notifications')}
              className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors relative hidden lg:flex"
            >
              <Bell className="w-5 h-5 text-[#2dd4bf]" strokeWidth={2} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-[#fb923c] rounded-full border border-[#0a0e27]" />
            </motion.button>
          </div>
        </div>
      </div>

      {/* Profile Header */}
      <div className="px-4 sm:px-6 lg:px-8 pb-4 sm:pb-6">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-white/10 to-white/[0.02] border border-white/20 rounded-3xl p-6 backdrop-blur-xl"
        >
          {/* Avatar & Name */}
          <div className="flex items-start gap-4 mb-6">
            {profile.profilePicture ? (
              <img 
                src={profile.profilePicture} 
                alt={profile.name}
                className="w-20 h-20 rounded-2xl object-cover shadow-lg"
              />
            ) : (
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#2dd4bf] to-[#a855f7] flex items-center justify-center text-3xl font-bold shadow-lg">
                {profile.initials}
              </div>
            )}
            <div className="flex-1">
              <h3 className="text-2xl font-bold mb-1">{profile.name}</h3>
              <p className="text-gray-400 mb-3">{profile.role} • {profile.location}</p>
              <motion.button 
                whileTap={{ scale: 0.95 }}
                whileHover={{ scale: 1.02 }}
                onClick={() => navigateTo('editProfile')}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#fb923c] to-[#f97316] rounded-xl font-semibold text-sm shadow-lg hover:shadow-xl transition-shadow active:shadow-md touch-manipulation"
              >
                <Edit2 className="w-4 h-4" />
                Edit Profile
              </motion.button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mb-6 pb-6 border-b border-white/10">
            <div className="text-center">
              <div className="text-2xl font-bold text-[#2dd4bf]">24</div>
              <div className="text-xs text-gray-400 mt-1">Connections</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#a855f7]">12</div>
              <div className="text-xs text-gray-400 mt-1">Matches</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#fb923c]">8</div>
              <div className="text-xs text-gray-400 mt-1">Posts</div>
            </div>
          </div>

          {/* Bio */}
          <div className="mb-4">
            <h4 className="text-sm font-semibold text-gray-400 mb-2 uppercase tracking-wider">Bio</h4>
            <p className="text-gray-300 leading-relaxed">
              {profile.bio}
            </p>
          </div>

          {/* Skills */}
          <div className="mb-4">
            <h4 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wider">Skills</h4>
            <div className="flex flex-wrap gap-2">
              {profile.skills.map((skill) => (
                <span key={skill} className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-full text-sm">
                  {skill}
                </span>
              ))}
            </div>
          </div>

          {/* Interests */}
          <div>
            <h4 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wider">Interests</h4>
            <div className="flex flex-wrap gap-2">
              {profile.interests.map((interest) => (
                <span key={interest} className="px-3 py-1.5 bg-gradient-to-r from-[#2dd4bf]/20 to-[#a855f7]/20 border border-[#2dd4bf]/50 rounded-full text-sm font-medium">
                  {interest}
                </span>
              ))}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Tabs */}
      <div className="px-4 sm:px-6 lg:px-8 mb-4">
        <div className="flex gap-2 bg-white/5 border border-white/10 rounded-2xl p-1.5 backdrop-blur-xl">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 h-10 rounded-xl font-medium text-sm transition-all duration-300 flex items-center justify-center gap-2 ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-[#2dd4bf] to-[#a855f7] text-white shadow-lg'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 pb-24 sm:pb-28 lg:pb-32">
        <div className="max-w-4xl mx-auto">
          {activeTab === 'overview' && (
            <motion.div
              key="overview"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-3"
            >
              <div className="bg-white/5 border border-white/10 rounded-2xl p-4 backdrop-blur-xl">
                <p className="text-gray-400 text-sm">
                  Complete your profile to get better matches. Add more skills and interests!
                </p>
              </div>
            </motion.div>
          )}

          {activeTab === 'saved' && (
            <motion.div
              key="saved"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-3"
            >
              {[1, 2].map((item) => (
                <div key={item} className="bg-white/5 border border-white/10 rounded-2xl p-4 backdrop-blur-xl">
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#2dd4bf] to-[#a855f7] flex items-center justify-center text-lg font-bold">
                      S{item}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold mb-1">Saved Item {item}</h4>
                      <p className="text-sm text-gray-400">Saved on Dec {10 + item}</p>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          )}

          {activeTab === 'liked' && (
            <motion.div
              key="liked"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-3"
            >
              {[1, 2, 3].map((item) => (
                <div key={item} className="bg-white/5 border border-white/10 rounded-2xl p-4 backdrop-blur-xl">
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#fb923c] to-[#f97316] flex items-center justify-center">
                      <Heart className="w-6 h-6 fill-white text-white" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold mb-1">Liked Post {item}</h4>
                      <p className="text-sm text-gray-400">Liked on Dec {8 + item}</p>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          )}

          {activeTab === 'activity' && (
            <motion.div
              key="activity"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-3"
            >
              {[
                { action: 'Connected with Sarah Chen', time: '2 hours ago' },
                { action: 'Posted "Looking for cofounder"', time: '1 day ago' },
                { action: 'Matched with Alex Kumar', time: '2 days ago' },
                { action: 'Updated profile', time: '3 days ago' }
              ].map((activity, index) => (
                <div key={index} className="bg-white/5 border border-white/10 rounded-2xl p-4 backdrop-blur-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-[#2dd4bf]" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{activity.action}</p>
                      <p className="text-xs text-gray-400 mt-1">{activity.time}</p>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}