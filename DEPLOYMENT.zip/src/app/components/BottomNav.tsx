import { motion } from 'motion/react';
import { Home, Users, MessageCircle, PlusCircle, User } from 'lucide-react';
import { Screen } from '../App';

interface BottomNavProps {
  currentScreen: Screen;
  navigateTo: (screen: Screen) => void;
}

export default function BottomNav({ currentScreen, navigateTo }: BottomNavProps) {
  const navItems = [
    { id: 'feed' as Screen, icon: Home, label: 'Home' },
    { id: 'match' as Screen, icon: Users, label: 'Matches' },
    { id: 'create' as Screen, icon: PlusCircle, label: 'Create', isSpecial: true },
    { id: 'chat' as Screen, icon: MessageCircle, label: 'Chat' },
    { id: 'profile' as Screen, icon: User, label: 'Profile' },
  ];

  return (
    <motion.div
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="fixed bottom-0 left-0 right-0 z-50 h-20 sm:h-24 bg-gradient-to-t from-[#0a0e27] via-[#0a0e27]/95 to-transparent backdrop-blur-xl border-t border-white/10 safe-bottom"
      style={{ 
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
    >
      <div className="h-full flex items-center justify-around px-2 sm:px-4 md:px-6 max-w-md sm:max-w-2xl md:max-w-3xl lg:max-w-4xl xl:max-w-6xl mx-auto">
        {navItems.map((item) => {
          const isActive = currentScreen === item.id || 
            (item.id === 'feed' && currentScreen === 'home');
          
          if (item.isSpecial) {
            return (
              <motion.button
                key={item.id}
                onClick={() => navigateTo(item.id)}
                whileTap={{ scale: 0.85 }}
                whileHover={{ scale: 1.05 }}
                className="relative -mt-10 sm:-mt-12 flex flex-col items-center touch-manipulation"
              >
                <motion.div 
                  className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-to-r from-[#fb923c] to-[#f97316] flex items-center justify-center shadow-2xl"
                  animate={{
                    boxShadow: [
                      '0 10px 40px rgba(251, 146, 60, 0.4)',
                      '0 10px 50px rgba(249, 115, 22, 0.5)',
                      '0 10px 40px rgba(251, 146, 60, 0.4)',
                    ]
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <item.icon className="w-6 h-6 sm:w-7 sm:h-7 text-white" strokeWidth={2.5} />
                </motion.div>
                <span className="text-[10px] sm:text-xs font-medium text-[#fb923c] mt-1.5 sm:mt-2">
                  {item.label}
                </span>
              </motion.button>
            );
          }

          return (
            <motion.button
              key={item.id}
              onClick={() => navigateTo(item.id)}
              whileTap={{ scale: 0.9 }}
              className="flex flex-col items-center gap-1 sm:gap-1.5 py-2 px-2 sm:px-3 min-w-[56px] sm:min-w-[64px] relative touch-manipulation"
            >
              <motion.div 
                className="relative"
                animate={{
                  y: isActive ? -2 : 0,
                }}
                transition={{ type: 'spring', stiffness: 400, damping: 17 }}
              >
                <item.icon 
                  className={`w-5 h-5 sm:w-6 sm:h-6 transition-colors ${
                    isActive ? 'text-[#2dd4bf]' : 'text-gray-400'
                  }`}
                  strokeWidth={isActive ? 2.5 : 2}
                />
                {isActive && (
                  <motion.div
                    layoutId="activeIndicator"
                    className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-[#2dd4bf] rounded-full"
                    transition={{ 
                      type: 'spring', 
                      stiffness: 500, 
                      damping: 30 
                    }}
                  />
                )}
              </motion.div>
              <motion.span 
                className={`text-[10px] sm:text-[11px] font-medium transition-colors ${
                  isActive ? 'text-[#2dd4bf]' : 'text-gray-400'
                }`}
                animate={{
                  scale: isActive ? 1.05 : 1,
                }}
                transition={{ type: 'spring', stiffness: 400, damping: 17 }}
              >
                {item.label}
              </motion.span>
            </motion.button>
          );
        })}
      </div>
    </motion.div>
  );
}