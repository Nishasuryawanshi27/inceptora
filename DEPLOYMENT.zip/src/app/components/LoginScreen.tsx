import { motion } from 'motion/react';
import { Mail, Chrome, ArrowLeft } from 'lucide-react';
import logo from 'figma:asset/589d6572b6c8eee2261523f1185cc1a693f70dd0.png';
import { useState } from 'react';
import { toast } from 'sonner';

interface LoginScreenProps {
  onLogin: (email: string, method: 'google' | 'email') => void;
}

export default function LoginScreen({ onLogin }: LoginScreenProps) {
  const [showEmailLogin, setShowEmailLogin] = useState(false);
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleGoogleLogin = () => {
    setIsLoading(true);
    // Simulate Google OAuth - in real app, this would open OAuth flow
    setTimeout(() => {
      onLogin('user@gmail.com', 'google');
      setIsLoading(false);
    }, 1000);
  };

  const handleSendOTP = () => {
    if (!email || !email.includes('@')) {
      toast.error('Please enter a valid email address');
      return;
    }
    setIsLoading(true);
    // Simulate sending OTP
    setTimeout(() => {
      setOtpSent(true);
      setIsLoading(false);
      toast.success('📧 OTP Code Sent!', {
        description: `Verification code sent to ${email}`,
        duration: 6000,
      });
    }, 1000);
  };

  const handleVerifyOTP = () => {
    if (!otp || otp.length < 4) {
      alert('Please enter a valid OTP');
      return;
    }
    setIsLoading(true);
    // Simulate OTP verification
    setTimeout(() => {
      onLogin(email, 'email');
      setIsLoading(false);
    }, 1000);
  };

  if (showEmailLogin) {
    return (
      <div className="h-full flex flex-col px-6 sm:px-8 relative overflow-hidden">
        {/* Header */}
        <div className="pt-8 sm:pt-12 pb-6">
          <button
            onClick={() => {
              setShowEmailLogin(false);
              setOtpSent(false);
              setEmail('');
              setOtp('');
            }}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        </div>

        {/* Email/OTP Form */}
        <div className="flex-1 flex flex-col justify-center pb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-md mx-auto w-full"
          >
            <div className="text-center mb-8">
              <div className="w-16 h-16 sm:w-20 sm:h-20 mx-auto bg-gradient-to-br from-[#fb923c] to-[#f97316] rounded-2xl flex items-center justify-center mb-4">
                <Mail className="w-8 h-8 sm:w-10 sm:h-10" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold mb-2">
                {otpSent ? 'Verify OTP' : 'Sign in with Email'}
              </h2>
              <p className="text-gray-400 text-sm sm:text-base">
                {otpSent
                  ? `Enter the code sent to ${email}`
                  : 'We\'ll send you a one-time password'}
              </p>
            </div>

            {!otpSent ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-400 mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="w-full h-14 px-4 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#2dd4bf] transition-colors"
                    disabled={isLoading}
                  />
                </div>
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={handleSendOTP}
                  disabled={isLoading}
                  className="w-full h-14 bg-gradient-to-r from-[#fb923c] to-[#f97316] rounded-xl font-semibold text-base shadow-lg hover:shadow-xl transition-all disabled:opacity-50"
                >
                  {isLoading ? 'Sending...' : 'Send OTP'}
                </motion.button>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-400 mb-2">
                    One-Time Password
                  </label>
                  <input
                    type="text"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/[^0-9]/g, '').slice(0, 6))}
                    placeholder="Enter 6-digit code"
                    className="w-full h-14 px-4 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#2dd4bf] transition-colors text-center text-2xl tracking-widest"
                    maxLength={6}
                    disabled={isLoading}
                  />
                </div>
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={handleVerifyOTP}
                  disabled={isLoading}
                  className="w-full h-14 bg-gradient-to-r from-[#2dd4bf] to-[#14b8a6] rounded-xl font-semibold text-base shadow-lg hover:shadow-xl transition-all disabled:opacity-50"
                >
                  {isLoading ? 'Verifying...' : 'Verify & Continue'}
                </motion.button>
                <button
                  onClick={() => setOtpSent(false)}
                  className="w-full text-sm text-gray-400 hover:text-white transition-colors"
                >
                  Resend OTP
                </button>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col items-center justify-center px-8 relative overflow-hidden">
      {/* Logo and Title */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="text-center mb-12"
      >
        <div className="mb-6 relative">
          <motion.div
            animate={{ 
              boxShadow: [
                '0 0 20px rgba(45, 212, 191, 0.3)',
                '0 0 40px rgba(168, 85, 247, 0.3)',
                '0 0 20px rgba(45, 212, 191, 0.3)',
              ]
            }}
            transition={{ duration: 3, repeat: Infinity }}
            className="w-24 h-24 mx-auto bg-gradient-to-br from-[#2dd4bf] to-[#a855f7] rounded-3xl flex items-center justify-center p-4"
          >
            <img src={logo} alt="Inceptora Logo" className="w-full h-full object-contain" />
          </motion.div>
        </div>
        
        <h1 className="text-5xl font-bold bg-gradient-to-r from-[#2dd4bf] via-[#a855f7] to-[#fb923c] bg-clip-text text-transparent mb-3">
          Inceptora
        </h1>
        <p className="text-gray-400 text-lg">
          Find your perfect team match
        </p>
      </motion.div>

      {/* Login Buttons */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="w-full space-y-4"
      >
        <button
          onClick={handleGoogleLogin}
          className="w-full h-14 bg-white text-gray-900 rounded-2xl flex items-center justify-center gap-3 font-semibold shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
        >
          <Chrome className="w-5 h-5" />
          Continue with Google
        </button>

        <button
          onClick={() => setShowEmailLogin(true)}
          className="w-full h-14 bg-gradient-to-r from-[#fb923c] to-[#f97316] text-white rounded-2xl flex items-center justify-center gap-3 font-semibold shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] relative overflow-hidden group"
        >
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-0 group-hover:opacity-20"
            animate={{ x: ['-100%', '100%'] }}
            transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 0.5 }}
          />
          <Mail className="w-5 h-5 relative z-10" />
          <span className="relative z-10">Continue with Email (OTP)</span>
        </button>
      </motion.div>

      {/* Footer */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.6 }}
        className="text-gray-500 text-sm text-center mt-12"
      >
        By continuing, you agree to our Terms & Privacy Policy
      </motion.p>

      {/* Decorative elements */}
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        className="absolute top-20 right-8 w-32 h-32 border border-[#2dd4bf]/20 rounded-full"
      />
      <motion.div
        animate={{ rotate: -360 }}
        transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
        className="absolute bottom-32 left-8 w-24 h-24 border border-[#a855f7]/20 rounded-full"
      />
    </div>
  );
}