import { useState } from 'react';
import { motion, PanInfo, AnimatePresence } from 'motion/react';
import { Heart, X, MapPin, Briefcase, GraduationCap, Star, ArrowLeft, Bell, Calendar, Filter } from 'lucide-react';
import { Screen } from '../App';

interface MatchScreenProps {
  navigateTo: (screen: Screen) => void;
}

const matches = [
  {
    id: 1,
    name: 'Emma Rodriguez',
    role: 'UX Designer',
    city: 'Los Angeles',
    match: '96%',
    skills: ['Design', 'Product', 'Figma'],
    bio: 'Looking for a technical cofounder to build the next big thing in AI-powered design tools.',
    stage: 'MVP',
    image: '🎨'
  },
  {
    id: 2,
    name: 'James Chen',
    role: 'Backend Engineer',
    city: 'Seattle',
    match: '92%',
    skills: ['Development', 'AI/ML', 'Python'],
    bio: 'Experienced engineer seeking cofounder for B2B SaaS startup.',
    stage: 'Idea',
    image: '💻'
  },
  {
    id: 3,
    name: 'Priya Sharma',
    role: 'Growth Marketer',
    city: 'Austin',
    match: '88%',
    skills: ['Marketing', 'Growth', 'Analytics'],
    bio: 'Helping startups scale. Looking for early-stage projects to mentor.',
    stage: 'Early Revenue',
    image: '📈'
  },
  {
    id: 4,
    name: 'Marcus Johnson',
    role: 'Product Manager',
    city: 'Boston',
    match: '85%',
    skills: ['Product', 'Strategy', 'Operations'],
    bio: 'Ex-FAANG PM looking to join or advise early-stage startups.',
    stage: 'Scaling',
    image: '🚀'
  }
];

export default function MatchScreen({ navigateTo }: MatchScreenProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showFilters, setShowFilters] = useState(false);

  const handleConnect = () => {
    if (currentIndex < matches.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  const handleSkip = () => {
    if (currentIndex < matches.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  const currentMatch = matches[currentIndex];

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#0a0e27] to-[#050811]">
      {/* Header */}
      <div className="px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12 pb-4 sm:pb-6">
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigateTo('feed')}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors touch-manipulation"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-lg sm:text-xl font-bold">Matches</h2>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors touch-manipulation"
          >
            <Filter className={`w-5 h-5 ${showFilters ? 'text-[#2dd4bf]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Filters */}
      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="px-4 sm:px-6 lg:px-8 pb-4"
          >
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 backdrop-blur-xl">
              <div className="flex flex-wrap gap-2">
                {['All', 'Cofounder', 'Tech', 'Marketing', 'Design'].map((filter) => (
                  <button
                    key={filter}
                    className="px-4 py-2 rounded-full bg-white/5 border border-white/10 text-sm hover:bg-[#2dd4bf]/20 hover:border-[#2dd4bf]/50 transition-colors"
                  >
                    {filter}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Match Card */}
      <div className="flex-1 px-4 sm:px-6 lg:px-8 pb-24 sm:pb-28 lg:pb-32 flex flex-col">
        <div className="max-w-4xl mx-auto w-full flex-1 flex flex-col">
          <motion.div
            key={currentMatch.id}
            initial={{ opacity: 0, scale: 0.9, rotateY: -10 }}
            animate={{ opacity: 1, scale: 1, rotateY: 0 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="flex-1 bg-gradient-to-br from-white/10 to-white/[0.02] border border-white/20 rounded-3xl overflow-hidden backdrop-blur-xl relative"
          >
            {/* Gradient overlay */}
            <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-b from-[#2dd4bf]/20 via-[#a855f7]/10 to-transparent" />
            
            <div className="relative h-full p-6 flex flex-col">
              {/* Top Section */}
              <div className="mb-6">
                <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-[#2dd4bf] to-[#a855f7] flex items-center justify-center text-5xl mb-4 shadow-lg">
                  {currentMatch.image}
                </div>
                
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold mb-1">{currentMatch.name}</h3>
                    <p className="text-gray-400">{currentMatch.role}</p>
                  </div>
                  <div className="flex items-center gap-2 bg-[#2dd4bf]/20 border border-[#2dd4bf]/50 rounded-full px-3 py-1">
                    <Star className="w-4 h-4 text-[#2dd4bf]" />
                    <span className="text-sm font-bold text-[#2dd4bf]">{currentMatch.match}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-gray-400 mb-4">
                  <MapPin className="w-4 h-4" />
                  <span className="text-sm">{currentMatch.city}</span>
                  <span className="text-sm">•</span>
                  <span className="text-sm">{currentMatch.stage}</span>
                </div>

                {/* Skills */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {currentMatch.skills.map((skill) => (
                    <span
                      key={skill}
                      className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-full text-sm"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Bio */}
              <div className="flex-1">
                <h4 className="text-sm font-semibold text-gray-400 mb-2 uppercase tracking-wider">About</h4>
                <p className="text-gray-300 leading-relaxed">{currentMatch.bio}</p>
              </div>

              {/* Match Reason */}
              <div className="mt-auto pt-4">
                <div className="bg-gradient-to-r from-[#2dd4bf]/10 to-[#a855f7]/10 border border-[#2dd4bf]/20 rounded-2xl p-4">
                  <p className="text-sm text-gray-300">
                    <span className="text-[#2dd4bf] font-semibold">Why match: </span>
                    Complementary skills and shared interest in early-stage startups
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Action Buttons */}
          <div className="flex gap-4 mt-6">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleSkip}
              className="flex-1 h-16 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center gap-2 font-semibold hover:bg-white/10 transition-colors group"
            >
              <X className="w-6 h-6 text-gray-400 group-hover:text-white transition-colors" />
              <span className="text-gray-400 group-hover:text-white transition-colors">Not Now</span>
            </motion.button>

            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleConnect}
              className="flex-1 h-16 bg-gradient-to-r from-[#fb923c] to-[#f97316] rounded-2xl flex items-center justify-center gap-2 font-semibold shadow-lg hover:shadow-xl transition-shadow relative overflow-hidden group"
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-0 group-hover:opacity-20"
                animate={{ x: ['-100%', '100%'] }}
                transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 0.5 }}
              />
              <Heart className="w-6 h-6 relative z-10" />
              <span className="relative z-10">Connect</span>
            </motion.button>
          </div>
        </div>
      </div>
    </div>
  );
}