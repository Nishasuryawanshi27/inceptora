import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Send, Image, Smile, Users, TrendingUp } from 'lucide-react';
import { Screen } from '../App';

interface CommunityChatScreenProps {
  navigateTo: (screen: Screen) => void;
  roomName?: string;
}

const chatRooms = [
  { id: 1, name: 'Founders Circle', members: 234, color: 'text-[#2dd4bf]', icon: '🚀', active: true },
  { id: 2, name: 'Design Talk', members: 156, color: 'text-[#a855f7]', icon: '🎨', active: true },
  { id: 3, name: 'Developer Hub', members: 389, color: 'text-[#fb923c]', icon: '💻', active: true },
  { id: 4, name: 'Marketing Masters', members: 178, color: 'text-[#06b6d4]', icon: '📈', active: false },
  { id: 5, name: 'Content Creators', members: 267, color: 'text-[#a855f7]', icon: '📹', active: true },
  { id: 6, name: 'Startup Mentors', members: 145, color: 'text-[#2dd4bf]', icon: '🎓', active: false },
];

const messages = [
  {
    id: 1,
    user: 'Sarah Chen',
    avatar: 'SC',
    message: 'Hey everyone! Just launched my MVP today! 🎉',
    time: '10:30 AM',
    isOwn: false,
  },
  {
    id: 2,
    user: 'Alex Kumar',
    avatar: 'AK',
    message: 'Congrats Sarah! Would love to check it out',
    time: '10:32 AM',
    isOwn: false,
  },
  {
    id: 3,
    user: 'You',
    avatar: 'JD',
    message: 'That\'s amazing! What tech stack did you use?',
    time: '10:35 AM',
    isOwn: true,
  },
  {
    id: 4,
    user: 'Sarah Chen',
    avatar: 'SC',
    message: 'React + Node.js + PostgreSQL. Been working on it for 3 months!',
    time: '10:36 AM',
    isOwn: false,
  },
  {
    id: 5,
    user: 'Maya Patel',
    avatar: 'MP',
    message: 'Nice stack! If you need help with marketing, let me know 😊',
    time: '10:38 AM',
    isOwn: false,
  },
];

export default function CommunityChatScreen({ navigateTo, roomName }: CommunityChatScreenProps) {
  const [selectedRoom, setSelectedRoom] = useState<number | null>(roomName ? 1 : null);
  const [messageText, setMessageText] = useState('');

  if (!selectedRoom) {
    return (
      <div className="h-full flex flex-col bg-gradient-to-b from-[#0a0e27] to-[#050811]">
        {/* Header */}
        <div className="px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12 pb-4 sm:pb-6">
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <button
              onClick={() => navigateTo('feed')}
              className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors touch-manipulation"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h2 className="text-lg sm:text-xl font-bold">Community Chats</h2>
            <div className="w-10" />
          </div>
        </div>

        {/* Chat Rooms */}
        <div className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 pb-24 sm:pb-28 lg:pb-32">
          <div className="max-w-4xl mx-auto space-y-3">
            {chatRooms.map((room, index) => (
              <motion.button
                key={room.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => setSelectedRoom(room.id)}
                className="w-full bg-gradient-to-br from-white/10 to-white/[0.02] border border-white/20 rounded-2xl p-5 backdrop-blur-xl hover:border-white/30 transition-colors text-left"
              >
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#2dd4bf]/20 to-[#a855f7]/20 border border-white/20 flex items-center justify-center text-2xl">
                    {room.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold mb-1">{room.name}</h3>
                    <div className="flex items-center gap-2 text-sm text-gray-400">
                      <Users className="w-4 h-4" />
                      <span>{room.members} members</span>
                      <TrendingUp className="w-4 h-4 text-[#2dd4bf] ml-2" />
                      <span className="text-[#2dd4bf]">Active</span>
                    </div>
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const currentRoom = chatRooms.find(r => r.id === selectedRoom);

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#0a0e27] to-[#050811]">
      {/* Header */}
      <div className="px-6 pt-12 pb-4 border-b border-white/10">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setSelectedRoom(null)}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1 text-center">
            <h3 className="font-bold flex items-center justify-center gap-2">
              <span className="text-xl">{currentRoom?.icon}</span>
              {currentRoom?.name}
            </h3>
            <p className="text-xs text-gray-400">{currentRoom?.members} members</p>
          </div>
          <div className="w-10" />
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-4">
        <div className="space-y-4">
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex gap-3 ${msg.isOwn ? 'flex-row-reverse' : ''}`}
            >
              {!msg.isOwn && (
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#2dd4bf] to-[#a855f7] flex items-center justify-center text-sm font-bold flex-shrink-0">
                  {msg.avatar}
                </div>
              )}
              <div className={`flex-1 ${msg.isOwn ? 'flex flex-col items-end' : ''}`}>
                {!msg.isOwn && (
                  <span className="text-xs text-gray-400 font-medium mb-1">{msg.user}</span>
                )}
                <div
                  className={`inline-block px-4 py-3 rounded-2xl max-w-[75%] ${
                    msg.isOwn
                      ? 'bg-gradient-to-r from-[#2dd4bf] to-[#14b8a6] text-white'
                      : 'bg-white/5 border border-white/10 text-gray-200'
                  }`}
                >
                  <p className="text-sm">{msg.message}</p>
                </div>
                <span className="text-xs text-gray-500 mt-1">{msg.time}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Message Input */}
      <div className="px-6 pb-28 pt-4 border-t border-white/10">
        <div className="flex items-center gap-3">
          <button className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors">
            <Image className="w-5 h-5 text-gray-400" />
          </button>
          <button className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors">
            <Smile className="w-5 h-5 text-gray-400" />
          </button>
          <div className="flex-1 relative">
            <input
              type="text"
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder="Type a message..."
              className="w-full h-12 px-4 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#2dd4bf] transition-colors"
            />
          </div>
          <motion.button
            whileTap={{ scale: 0.95 }}
            className="w-12 h-12 rounded-xl bg-gradient-to-r from-[#fb923c] to-[#f97316] flex items-center justify-center shadow-lg"
          >
            <Send className="w-5 h-5 text-white" />
          </motion.button>
        </div>
      </div>
    </div>
  );
}