import { motion } from 'motion/react';
import { TrendingUp, Sparkles, ArrowRight, Bell, Calendar, MessageCircle, Heart, Bookmark, Users } from 'lucide-react';
import { Screen } from '../App';
import { useState } from 'react';

interface HomeScreenProps {
  navigateTo: (screen: Screen) => void;
}

const featuredMatches = [
  { name: 'Sarah Chen', role: 'Product Designer', match: '95%', city: 'San Francisco', skills: ['Design', 'UI/UX'] },
  { name: 'Alex Kumar', role: 'Full Stack Dev', match: '89%', city: 'New York', skills: ['Development', 'AI/ML'] },
  { name: 'Maya Patel', role: 'Marketing Lead', match: '87%', city: 'London', skills: ['Marketing', 'Growth'] },
];

const communityPosts = [
  {
    id: 1,
    author: 'Emma Rodriguez',
    avatar: '🎨',
    time: '2h ago',
    type: 'Cofounder',
    content: 'Seeking a technical cofounder for an AI-powered design tool. Looking for someone passionate about transforming the creative workflow.',
    likes: 24,
    comments: 8,
    isLiked: false,
    isSaved: false
  },
  {
    id: 2,
    author: 'James Chen',
    avatar: '💻',
    time: '5h ago',
    type: 'Feedback',
    content: 'Just built an MVP for B2B SaaS productivity tool. Would love some feedback from fellow founders and designers!',
    likes: 18,
    comments: 12,
    isLiked: false,
    isSaved: false
  },
  {
    id: 3,
    author: 'Sophie Martinez',
    avatar: '🚀',
    time: '8h ago',
    type: 'Collaboration',
    content: 'Working on a climate tech startup. Looking for UX designers and environmental scientists to join the mission!',
    likes: 32,
    comments: 15,
    isLiked: false,
    isSaved: false
  },
  {
    id: 4,
    author: 'David Kim',
    avatar: '📱',
    time: '12h ago',
    type: 'Question',
    content: 'What are your top 3 tools for rapid prototyping? Building a mobile app and need recommendations.',
    likes: 45,
    comments: 28,
    isLiked: false,
    isSaved: false
  }
];

export default function HomeScreen({ navigateTo }: HomeScreenProps) {
  const [posts, setPosts] = useState(communityPosts);

  const toggleLike = (postId: number) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          isLiked: !post.isLiked,
          likes: post.isLiked ? post.likes - 1 : post.likes + 1
        };
      }
      return post;
    }));
  };

  const toggleSave = (postId: number) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          isSaved: !post.isSaved
        };
      }
      return post;
    }));
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#0a0e27] to-[#050811]">
      {/* Header */}
      <div className="px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12 pb-4 sm:pb-6">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-6 sm:mb-8"
        >
          <div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold bg-gradient-to-r from-[#2dd4bf] to-[#a855f7] bg-clip-text text-transparent">
              Inceptora
            </h1>
            <p className="text-gray-400 mt-1 text-sm sm:text-base">Welcome back! 👋</p>
          </div>
          <div className="flex items-center gap-2">
            <motion.button
              whileTap={{ scale: 0.9 }}
              whileHover={{ scale: 1.05 }}
              onClick={() => navigateTo('events')}
              className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors relative"
            >
              <Calendar className="w-5 h-5 text-[#a855f7]" strokeWidth={2} />
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.9 }}
              whileHover={{ scale: 1.05 }}
              onClick={() => navigateTo('notifications')}
              className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors relative"
            >
              <Bell className="w-5 h-5 text-[#2dd4bf]" strokeWidth={2} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-[#fb923c] rounded-full border border-[#0a0e27]" />
            </motion.button>
          </div>
        </motion.div>
      </div>

      {/* Content - Community Feed */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 pb-24 sm:pb-28 lg:pb-32">
        <div className="max-w-4xl mx-auto">
          {/* Community Feed Header */}
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <h3 className="text-lg sm:text-xl font-bold text-white">Community Feed</h3>
            <div className="flex items-center gap-2">
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => navigateTo('community')}
                className="px-3 sm:px-4 py-2 bg-gradient-to-r from-[#06b6d4]/20 to-[#0891b2]/20 border border-[#06b6d4]/30 rounded-xl flex items-center gap-2 hover:border-[#06b6d4]/50 transition-colors"
              >
                <Users className="w-4 h-4 text-[#06b6d4]" />
                <span className="text-xs sm:text-sm font-medium text-[#06b6d4] hidden sm:inline">Join Chats</span>
              </motion.button>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => navigateTo('create')}
                className="px-3 sm:px-4 py-2 bg-gradient-to-r from-[#2dd4bf] to-[#14b8a6] rounded-xl text-xs sm:text-sm font-semibold hover:opacity-90 transition-opacity"
              >
                <span className="hidden sm:inline">Create Post</span>
                <span className="sm:hidden">+</span>
              </motion.button>
            </div>
          </div>

          {/* Community Posts */}
          <div className="space-y-4">
            {posts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-gradient-to-br from-white/10 to-white/[0.02] border border-white/20 rounded-2xl sm:rounded-3xl p-4 sm:p-6 backdrop-blur-xl hover:border-white/30 transition-colors"
              >
                {/* Post Header */}
                <div className="flex items-start gap-3 mb-3 sm:mb-4">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-gradient-to-br from-[#2dd4bf] to-[#a855f7] flex items-center justify-center text-lg sm:text-xl flex-shrink-0">
                    {post.avatar}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-sm sm:text-base truncate">{post.author}</h4>
                    <p className="text-xs text-gray-400">{post.time}</p>
                  </div>
                  <span className="px-2 sm:px-3 py-1 bg-gradient-to-r from-[#fb923c]/20 to-[#f97316]/20 border border-[#fb923c]/50 rounded-full text-[10px] sm:text-xs font-medium flex-shrink-0 whitespace-nowrap">
                    {post.type}
                  </span>
                </div>

                {/* Post Content */}
                <p className="text-gray-300 text-sm sm:text-base mb-4 leading-relaxed">{post.content}</p>

                {/* Actions */}
                <div className="flex items-center gap-3 sm:gap-4 pt-3 sm:pt-4 border-t border-white/10">
                  <motion.button 
                    whileTap={{ scale: 0.9 }}
                    onClick={() => toggleLike(post.id)}
                    className={`flex items-center gap-1.5 sm:gap-2 transition-colors ${
                      post.isLiked ? 'text-[#fb923c]' : 'text-gray-400 hover:text-[#fb923c]'
                    }`}
                  >
                    <Heart className={`w-4 h-4 sm:w-5 sm:h-5 ${post.isLiked ? 'fill-current' : ''}`} />
                    <span className="text-xs sm:text-sm font-medium">{post.likes}</span>
                  </motion.button>
                  <motion.button 
                    whileTap={{ scale: 0.9 }}
                    onClick={() => navigateTo('feed')}
                    className="flex items-center gap-1.5 sm:gap-2 text-gray-400 hover:text-[#2dd4bf] transition-colors"
                  >
                    <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5" />
                    <span className="text-xs sm:text-sm font-medium">{post.comments}</span>
                  </motion.button>
                  <motion.button 
                    whileTap={{ scale: 0.9 }}
                    onClick={() => toggleSave(post.id)}
                    className={`ml-auto transition-colors ${
                      post.isSaved ? 'text-[#a855f7]' : 'text-gray-400 hover:text-[#a855f7]'
                    }`}
                  >
                    <Bookmark className={`w-4 h-4 sm:w-5 sm:h-5 ${post.isSaved ? 'fill-current' : ''}`} />
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}