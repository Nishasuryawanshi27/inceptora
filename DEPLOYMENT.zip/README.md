
  # inceptora2

  This is a code bundle for inceptora2. The original project is available at https://www.figma.com/design/ENQeE6KCgfLWffQ2jBfZ2e/inceptora2.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  